import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCustomStreamingConnector40Item = function SvgCustomStreamingConnector40Item(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 40,
    height: 40,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i491c42-ifd8144-paint0_linear_62220_759)",
    d: "M4 8a4 4 0 0 1 4-4h24a4 4 0 0 1 4 4v17.125C36 27.335 34.21 36 32 36H8a4 4 0 0 1-4-4z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i491c42-ifd8144-paint1_radial_62220_759)",
    fillOpacity: 0.2,
    d: "M4 8a4 4 0 0 1 4-4h24a4 4 0 0 1 4 4v17.125C36 27.335 34.21 36 32 36H8a4 4 0 0 1-4-4z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i491c42-ifd8144-paint2_linear_62220_759)",
    fillRule: "evenodd",
    d: "M32 5H8a3 3 0 0 0-3 3v24a3 3 0 0 0 3 3h24c1.657 0 3-3.812 3-5.469V8a3 3 0 0 0-3-3M8 4a4 4 0 0 0-4 4v24a4 4 0 0 0 4 4h24c2.21 0 4-8.26 4-10.469V8a4 4 0 0 0-4-4z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i491c42-ifd8144-paint3_linear_62220_759)",
    d: "M27.78 13.28a.75.75 0 1 0-1.06-1.06l-2.446 2.445a4.04 4.04 0 0 0-5.128.482l-.3.3a1.49 1.49 0 0 0 0 2.107l3.6 3.6a1.49 1.49 0 0 0 2.107 0l.3-.3a4.04 4.04 0 0 0 .481-5.128zm-10.226 5.566a1.49 1.49 0 0 0-2.107 0l-.3.3a4.04 4.04 0 0 0-.482 5.128L12.22 26.72a.75.75 0 1 0 1.06 1.06l2.446-2.446a4.04 4.04 0 0 0 5.128-.48l.3-.3a1.49 1.49 0 0 0 0-2.108z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#F5F5F5",
    fillRule: "evenodd",
    d: "M36.5 24a1.5 1.5 0 0 1 1.4 2.033 1.5 1.5 0 0 1 .757 2.513c.214.26.343.591.343.954l-.008.153a1.5 1.5 0 0 1-1.339 1.34L37.5 31h-2.499q0 .025-.003.047l.002.03V32a6 6 0 0 1-5.691 5.992L29 38h-2.5a1.5 1.5 0 0 1-1.5-1.5l.008-.153a1.5 1.5 0 0 1 .098-.4 1.5 1.5 0 0 1-1.098-1.294L24 34.5l.008-.153c.033-.325.17-.617.377-.847a1.5 1.5 0 0 1-.377-.847L24 32.5l.008-.153A1.5 1.5 0 0 1 25.5 31H28v-1a6 6 0 0 1 6-6z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i491c42-ifd8144-paint4_linear_62220_759)",
    d: "M37.5 29a.5.5 0 0 1 0 1h-2.499a1 1 0 0 0-1 1l-.005.043.004.034V32a5 5 0 0 1-5 5h-2.5a.5.5 0 0 1 0-1H29a4 4 0 0 0 4-4v-.923q0-.022.004-.046L33.001 31a2 2 0 0 1 2-2z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i491c42-ifd8144-paint5_linear_62220_759)",
    d: "M37.584 27a.5.5 0 0 1 0 1H34.5a2.5 2.5 0 0 0-2.5 2.5v1a3.5 3.5 0 0 1-3.5 3.5h-3a.5.5 0 0 1 0-1h3a2.5 2.5 0 0 0 2.5-2.5v-1a3.5 3.5 0 0 1 3.5-3.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i491c42-ifd8144-paint6_linear_62220_759)",
    d: "M36.5 25a.5.5 0 0 1 0 1H34a4 4 0 0 0-4 4v1.227l-.004.033.004.032c0 .943-.765 1.708-1.708 1.708H25.5a.5.5 0 0 1 0-1h2.792a.71.71 0 0 0 .708-.708l.003-.032-.003-.033V30a5 5 0 0 1 5-5z"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i491c42-ifd8144-paint0_linear_62220_759",
    x1: 12.889,
    x2: 16.937,
    y1: 4,
    y2: 36.383,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#EBEBEB"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i491c42-ifd8144-paint1_radial_62220_759",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "rotate(56.31 -4.411 19.454)scale(30.4469 26.3483)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.177,
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#B8B8B8"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i491c42-ifd8144-paint2_linear_62220_759",
    x1: 14.333,
    x2: 18.642,
    y1: 4,
    y2: 36.314,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#BBB"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#888"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i491c42-ifd8144-paint3_linear_62220_759",
    x1: 12,
    x2: 28,
    y1: 12,
    y2: 28,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i491c42-ifd8144-paint4_linear_62220_759",
    x1: 25,
    x2: 36.955,
    y1: 25,
    y2: 38.035,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i491c42-ifd8144-paint5_linear_62220_759",
    x1: 25,
    x2: 36.955,
    y1: 25,
    y2: 38.035,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i491c42-ifd8144-paint6_linear_62220_759",
    x1: 25,
    x2: 36.955,
    y1: 25,
    y2: 38.035,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCustomStreamingConnector40Item);

export { ForwardRef as default };
