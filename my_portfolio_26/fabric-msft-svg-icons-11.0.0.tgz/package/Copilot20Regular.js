import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot20Regular = function SvgCopilot20Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M16.082 5.048a3.5 3.5 0 0 1 2.81 4.308l-1.768 7.001A3.5 3.5 0 0 1 13.73 19H9.002a3.5 3.5 0 0 1-3.394-4.358l.067-.265c.076-.214.244-.377.485-.377h3.068a2.5 2.5 0 0 0 2.424-1.888l1.196-4.734a.5.5 0 0 1 .97.244l-1.196 4.735A3.5 3.5 0 0 1 9.228 15H6.553a2.5 2.5 0 0 0 2.449 3h4.728a2.5 2.5 0 0 0 2.424-1.888l1.769-7a2.5 2.5 0 0 0-2.005-3.078.5.5 0 0 1 .164-.986M10.998 1a3.5 3.5 0 0 1 3.392 4.357l-.066.265a.5.5 0 0 1-.485.378h-3.067a2.5 2.5 0 0 0-2.424 1.887l-1.197 4.736a.5.5 0 0 1-.97-.246L7.38 7.642A3.5 3.5 0 0 1 10.772 5h2.674a2.5 2.5 0 0 0-2.448-3H6.27a2.5 2.5 0 0 0-2.424 1.887l-1.77 7a2.5 2.5 0 0 0 2.005 3.079.5.5 0 1 1-.164.986 3.5 3.5 0 0 1-2.81-4.31l1.77-7A3.5 3.5 0 0 1 6.27 1z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot20Regular);

export { ForwardRef as default };
