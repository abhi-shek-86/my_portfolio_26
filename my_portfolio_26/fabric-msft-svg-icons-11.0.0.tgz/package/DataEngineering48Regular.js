import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataEngineering48Regular = function SvgDataEngineering48Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 48,
    height: 48,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M26.24 28.5c8.52-5.03 13.06-11.85 13.06-11.85h-.01c1.69-2.48 4.76-.8 4.76 1.85v10.89c-.05.94-.46 1.84-1.13 2.51l-1.22 1.22-6.26 6.28h-.01l-3.73 3.67c-.6.58-1.39.94-2.21.94h-13.3c-.88 0-1.72-.37-2.33-1.02l-9.203-9.919C4.153 32.568 4 31.77 4 31.03v-13.8c0-.91.35-1.77.97-2.41l9.58-9.85c.61-.62 1.43-.97 2.28-.97h15.58c1.21 0 2 1.24 1.42 2.36-1.39 2.7-4.24 7.24-9.16 11.1-1.62 1.28-3 2.41-4.22 3.45l2.39 3.77c1.091 1.712 2.013 2.767 3.4 3.82m2.29 1.53a46.9 46.9 0 0 0 11.11-9.75 52 52 0 0 0 1.382-1.802l.268-.358c.03-.05.06-.08.08-.1.04.03.09.07.14.14.06.09.1.2.1.34v10.8c-.01.13-.05.26-.11.38v-.01c-.22.5-1.1 1.11-2.36 1.57-2.28.85-5.81 1.23-8.91-.3-.742-.367-1.054-.519-1.7-.91M6.69 16.64c-.15.16-.24.37-.24.59h-.01v13.81c0 .22.09.43.23.58l2.64 2.83c.02-.75.11-1.49.26-2.22.49-2.34 1.14-4.5 3.2-7.17 1.95-2.53 5.12-5.46 10.44-9.64 3.77-2.97 6.24-6.38 7.7-8.87H16.83c-.21 0-.41.09-.56.24zm22.8 24.82c.15 0 .35-.07.54-.25l6.87-6.81c-2.32.31-5.1.14-7.71-1.15-3.45-1.71-6.1-3.59-8.39-7.17l-2.23-3.53c-5.05 4.62-5.94 7.01-6.61 10.2-.42 2.01-.26 3.92 1.02 5.61l2.63 2.85c.15.16.36.25.57.25z",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataEngineering48Regular);

export { ForwardRef as default };
