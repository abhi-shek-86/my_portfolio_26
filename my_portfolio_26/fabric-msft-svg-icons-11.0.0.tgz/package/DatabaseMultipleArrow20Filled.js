import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseMultipleArrow20Filled = function SvgDatabaseMultipleArrow20Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M12 16.499c0 1.38-2.015 2.5-4.5 2.5s-4.5-1.12-4.5-2.5v-3.945c.255.229.54.425.832.588.99.55 2.288.858 3.668.858s2.679-.309 3.668-.858c.293-.163.578-.36.833-.59L12 16.5ZM19 14c0 1.657-2.686 3-6 3h-.05q.049-.24.05-.501l.001-3.946.001-2.247-.009.008c-.08-1.1-.87-1.914-1.805-2.442C11.77 7.956 12.378 8 13 8c1.778 0 3.438-.359 4.69-.984A5.5 5.5 0 0 0 19 6.12z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M7.5 8c.481 0 .944.042 1.379.12.4.07.778.173 1.121.3 1.206.45 2 1.213 2 2.08 0 1.38-2.015 2.5-4.5 2.5S3 11.88 3 10.5 5.015 8 7.5 8M4.146 1.146a.5.5 0 0 1 .708 0l2 2q.05.052.082.113a.5.5 0 0 1 .054.339.5.5 0 0 1-.054.142q-.01.02-.021.037a.5.5 0 0 1-.061.077l-2 2a.5.5 0 0 1-.708-.708L5.293 4H4.5c-.923 0-1.523.23-1.896.604C2.23 4.977 2 5.577 2 6.5v2a.5.5 0 0 1-1 0v-2c0-1.077.27-1.977.896-2.604C2.523 3.27 3.423 3 4.5 3h.793L4.146 1.854a.5.5 0 0 1 0-.708M13 1c3.314 0 6 1.343 6 3s-2.686 3-6 3c-2.133 0-4.005-.557-5.07-1.396l.338-.336a2.5 2.5 0 0 0 .238-3.255C9.606 1.392 11.21 1 13 1"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseMultipleArrow20Filled);

export { ForwardRef as default };
