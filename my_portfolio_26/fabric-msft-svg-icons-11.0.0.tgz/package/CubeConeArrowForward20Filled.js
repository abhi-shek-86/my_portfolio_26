import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCubeConeArrowForward20Filled = function SvgCubeConeArrowForward20Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M6.97 1.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.75.75 0 0 1-1.06-1.06l.72-.72H6.5c-.69 0-1.25.56-1.25 1.25a.75.75 0 0 1-1.5 0A2.75 2.75 0 0 1 6.5 3.75h1.19l-.72-.72a.75.75 0 0 1 0-1.06"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10.051 9.489a1.5 1.5 0 0 1 .523.347l2.981-6.033a.45.45 0 0 1 .187-.2.5.5 0 0 1 .25-.063H14l.008-.003a.5.5 0 0 1 .25.063.45.45 0 0 1 .187.2l3.305 6.69q.11.228.18.47.07.244.07.5c0 .292-.081.58-.235.828a2.8 2.8 0 0 1-.585.68q-.357.303-.782.5a7 7 0 0 1-.8.32 5.3 5.3 0 0 1-1.524.227l-.039-.003a.4.4 0 0 0-.078 0l-.039.003a5.3 5.3 0 0 1-1.524-.227 7 7 0 0 1-.8-.32 3.4 3.4 0 0 1-.594-.351v1.997a1.5 1.5 0 0 1-.949 1.395l-3.5 1.384a1.5 1.5 0 0 1-1.102 0l-3.5-1.384A1.5 1.5 0 0 1 1 15.114v-4.23a1.5 1.5 0 0 1 .949-1.395l3.5-1.384a1.5 1.5 0 0 1 1.102 0zm-6.365 1.547a.5.5 0 1 0-.372.928l2.186.874V15a.5.5 0 0 0 1 0v-2.162l2.186-.874a.5.5 0 1 0-.372-.928L6 11.96z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCubeConeArrowForward20Filled);

export { ForwardRef as default };
