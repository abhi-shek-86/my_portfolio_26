import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCalendarMonthLink32Filled = function SvgCalendarMonthLink32Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M3 7.5A4.5 4.5 0 0 1 7.5 3h17A4.5 4.5 0 0 1 29 7.5v11.192A5.7 5.7 0 0 0 26.273 18h-6.546c-.79 0-1.543.16-2.228.451a1.5 1.5 0 1 0-2.029 1.453A5.74 5.74 0 0 0 14 23.75 5.75 5.75 0 0 0 17.388 29H7.5A4.5 4.5 0 0 1 3 24.5zm9 5a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0M10.5 20a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m5.5-6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m5.5 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M15.5 23.75a4.25 4.25 0 0 1 4.25-4.25h1a.75.75 0 0 1 0 1.5h-1a2.75 2.75 0 1 0 0 5.5h1a.75.75 0 0 1 0 1.5h-1a4.25 4.25 0 0 1-4.25-4.25m15 0a4.25 4.25 0 0 0-4.25-4.25h-1.5a.75.75 0 0 0 0 1.5h1.5a2.75 2.75 0 1 1 0 5.5h-1.5a.75.75 0 0 0 0 1.5h1.5a4.25 4.25 0 0 0 4.25-4.25"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M19.5 23.75a.75.75 0 0 1 .75-.75h5.5a.75.75 0 0 1 0 1.5h-5.5a.75.75 0 0 1-.75-.75"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCalendarMonthLink32Filled);

export { ForwardRef as default };
