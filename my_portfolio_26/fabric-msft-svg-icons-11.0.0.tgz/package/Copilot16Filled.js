import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot16Filled = function SvgCopilot16Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    fill: "currentColor",
    viewBox: "0 0 16 16",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillOpacity: 0.859,
    d: "M12.778 5a2.25 2.25 0 0 1 2.178 2.816l-1.285 4.94A3 3 0 0 1 10.768 15H7.53a2.25 2.25 0 0 1-2.176-2.818L5.663 11h1.438a2.25 2.25 0 0 0 2.177-1.684L10.402 5zM8.531 1a2.25 2.25 0 0 1 2.178 2.816L10.402 5H8.967A2.25 2.25 0 0 0 6.79 6.682L5.663 11H3.284a2.25 2.25 0 0 1-2.176-2.818l1.289-4.94A3 3 0 0 1 5.299 1z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot16Filled);

export { ForwardRef as default };
