import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCustomStreamingConnector20Item = function SvgCustomStreamingConnector20Item(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i26ceb1-i3869c4-paint0_linear_62220_725)",
    d: "M2 4.5A2.5 2.5 0 0 1 4.5 2h11A2.5 2.5 0 0 1 18 4.5v7.031C18 12.912 16.88 18 15.5 18h-11A2.5 2.5 0 0 1 2 15.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i26ceb1-i3869c4-paint1_radial_62220_725)",
    fillOpacity: 0.2,
    d: "M2 4.5A2.5 2.5 0 0 1 4.5 2h11A2.5 2.5 0 0 1 18 4.5v7.031C18 12.912 16.88 18 15.5 18h-11A2.5 2.5 0 0 1 2 15.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i26ceb1-i3869c4-paint2_linear_62220_725)",
    fillRule: "evenodd",
    d: "M15.5 3h-11A1.5 1.5 0 0 0 3 4.5v11A1.5 1.5 0 0 0 4.5 17h11a1.5 1.5 0 0 0 1.5-1.5v-11A1.5 1.5 0 0 0 15.5 3m-11-1A2.5 2.5 0 0 0 2 4.5v11A2.5 2.5 0 0 0 4.5 18h11c1.38 0 2.5-4.713 2.5-6.094V4.5A2.5 2.5 0 0 0 15.5 2z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i26ceb1-i3869c4-paint3_linear_62220_725)",
    d: "M10.912 11.53c.4.4.4 1.048 0 1.447-.944.944-2.42 1.037-3.486.304l-1.315 1.315a.5.5 0 0 1-.707-.707l1.315-1.315c-.733-1.065-.64-2.542.304-3.486.4-.4 1.047-.4 1.446 0zm3.684-6.126a.5.5 0 0 1 0 .707l-1.315 1.315c.734 1.065.64 2.542-.304 3.486-.4.4-1.047.4-1.446 0L9.088 8.47c-.4-.4-.4-1.047 0-1.446.944-.944 2.421-1.038 3.486-.304l1.315-1.315a.5.5 0 0 1 .707 0"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#F5F5F5",
    fillRule: "evenodd",
    d: "M16.965 8.008A1.5 1.5 0 0 1 18.224 10h.276a1.5 1.5 0 0 1 1.115 2.5c.207.23.344.522.377.847L20 13.5a1.5 1.5 0 0 1-1.5 1.5h-1a5 5 0 0 1-4.743 4.993L12.5 20h-1a1.5 1.5 0 0 1-1.5-1.5l.008-.153a1.5 1.5 0 0 1 .098-.4 1.5 1.5 0 0 1-1.098-1.294L9 16.5l.008-.153c.033-.325.17-.617.377-.847a1.5 1.5 0 0 1-.377-.847L9 14.5l.008-.153A1.5 1.5 0 0 1 10.5 13h.533a5.615 5.615 0 0 1 5.581-5h.197z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i26ceb1-i3869c4-paint4_linear_62220_725)",
    d: "M18.5 13a.5.5 0 0 1 0 1h-1.306a.695.695 0 0 0-.694.694l-.002.012.002.013V15a4 4 0 0 1-4 4h-1a.5.5 0 0 1 0-1h1a3 3 0 0 0 3-3v-.281l.001-.013-.001-.012c0-.935.759-1.694 1.694-1.694z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i26ceb1-i3869c4-paint5_linear_62220_725)",
    d: "M18.5 11a.5.5 0 0 1 0 1h-1.602C15.85 12 15 12.85 15 13.898V14a3 3 0 0 1-3 3h-1.5a.5.5 0 0 1 0-1H12a2 2 0 0 0 2-2v-.148l.001-.018A2.9 2.9 0 0 1 16.898 11z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i26ceb1-i3869c4-paint6_linear_62220_725)",
    d: "M16.81 9a.5.5 0 0 1 0 1h-.196A3.614 3.614 0 0 0 13 13.614 1.406 1.406 0 0 1 11.594 15H10.5a.5.5 0 0 1 0-1h1.094a.406.406 0 0 0 .406-.406v-.008A4.615 4.615 0 0 1 16.614 9z"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i26ceb1-i3869c4-paint0_linear_62220_725",
    x1: 6.444,
    x2: 8.468,
    y1: 2,
    y2: 18.192,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#EBEBEB"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i26ceb1-i3869c4-paint1_radial_62220_725",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "rotate(56.31 -2.206 9.727)scale(15.2234 13.1741)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.177,
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#B8B8B8"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i26ceb1-i3869c4-paint2_linear_62220_725",
    x1: 7.167,
    x2: 9.321,
    y1: 2,
    y2: 18.157,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#BBB"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#888"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i26ceb1-i3869c4-paint3_linear_62220_725",
    x1: 12.652,
    x2: 16.458,
    y1: 3.459,
    y2: 12.848,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i26ceb1-i3869c4-paint4_linear_62220_725",
    x1: 10,
    x2: 19.945,
    y1: 9,
    y2: 17.95,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i26ceb1-i3869c4-paint5_linear_62220_725",
    x1: 10,
    x2: 19.945,
    y1: 9,
    y2: 17.95,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i26ceb1-i3869c4-paint6_linear_62220_725",
    x1: 10,
    x2: 19.945,
    y1: 9,
    y2: 17.95,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCustomStreamingConnector20Item);

export { ForwardRef as default };
