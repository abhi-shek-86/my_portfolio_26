import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot32Regular = function SvgCopilot32Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M25 8c3.908 0 6.773 3.678 5.816 7.467L28.289 25.47A6 6 0 0 1 22.47 30h-6.703c-3.792 0-6.571-3.569-5.642-7.245.15-.43.488-.755.97-.755h2.375a4 4 0 0 0 3.878-3.02l1.573-6.225a1 1 0 1 1 1.939.49l-1.573 6.225A6 6 0 0 1 13.471 24h-1.517c-.107 2.124 1.587 4 3.814 4h6.703a4 4 0 0 0 3.878-3.02l2.527-10.003C29.514 12.45 27.605 10 25 10a1 1 0 0 1 0-2M16.23 2c3.792 0 6.571 3.569 5.643 7.245a1 1 0 0 1-.97.755H18.53a4 4 0 0 0-3.878 3.02l-1.575 6.225a1 1 0 0 1-1.94-.49l1.575-6.227A6 6 0 0 1 18.531 8h1.513c.106-2.124-1.588-4-3.815-4H9.53a4 4 0 0 0-3.878 3.02l-2.53 10C2.482 19.547 4.392 22 7 22a1 1 0 0 1 0 2c-3.91 0-6.775-3.68-5.816-7.47l2.53-10.002A6 6 0 0 1 9.53 2z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot32Regular);

export { ForwardRef as default };
