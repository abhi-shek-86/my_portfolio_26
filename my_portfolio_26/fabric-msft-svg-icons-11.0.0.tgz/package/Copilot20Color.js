import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot20Color = function SvgCopilot20Color(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i995600-paint0_linear_42584_82286)",
    d: "M10.5 1H6.551a4 4 0 0 0-3.878 3.02l-1.58 6.244A3 3 0 0 0 4.002 14H6.91l1.451-5.736A3 3 0 0 1 11.27 6h1.819l.32-1.265A3 3 0 0 0 10.498 1"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i995600-paint1_radial_42584_82286)",
    d: "M10.5 1H6.551a4 4 0 0 0-3.878 3.02l-1.58 6.244A3 3 0 0 0 4.002 14H6.91l1.451-5.736A3 3 0 0 1 11.27 6h1.819l.32-1.265A3 3 0 0 0 10.498 1"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i995600-paint2_linear_42584_82286)",
    d: "M10.5 1H6.551a4 4 0 0 0-3.878 3.02l-1.58 6.244A3 3 0 0 0 4.002 14H6.91l1.451-5.736A3 3 0 0 1 11.27 6h1.819l.32-1.265A3 3 0 0 0 10.498 1"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#D9D9D9",
    d: "m17.327 15.98 1.578-6.245A3 3 0 0 0 15.996 6H13.09l-1.45 5.735A3 3 0 0 1 8.732 14h-1.82l-.32 1.264A3 3 0 0 0 9.499 19h3.95a4 4 0 0 0 3.878-3.02"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i995600-paint3_radial_42584_82286)",
    d: "m17.327 15.98 1.578-6.245A3 3 0 0 0 15.996 6H13.09l-1.45 5.735A3 3 0 0 1 8.732 14h-1.82l-.32 1.264A3 3 0 0 0 9.499 19h3.95a4 4 0 0 0 3.878-3.02"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i995600-paint4_linear_42584_82286)",
    d: "m17.327 15.98 1.578-6.245A3 3 0 0 0 15.996 6H13.09l-1.45 5.735A3 3 0 0 1 8.732 14h-1.82l-.32 1.264A3 3 0 0 0 9.499 19h3.95a4 4 0 0 0 3.878-3.02"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i995600-paint0_linear_42584_82286",
    x1: 5.353,
    x2: 5.466,
    y1: 2.575,
    y2: 14.568,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.178,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD000"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i995600-paint1_radial_42584_82286",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(-8.51115 14.9834 -33.9182 -11.9115 11.077 1)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.252,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD400"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i995600-paint2_linear_42584_82286",
    x1: 6.521,
    x2: 6.456,
    y1: 1,
    y2: 14,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#3DCBFF"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.247,
    stopColor: "#0588F7",
    stopOpacity: 0
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i995600-paint3_radial_42584_82286",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(6.91174 -16.0666 40.525 13.8604 7.975 20.034)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.074,
    stopColor: "#FFB152"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.5,
    stopColor: "#F2598A"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.948,
    stopColor: "#8C48FF"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i995600-paint4_linear_42584_82286",
    x1: 14.409,
    x2: 14.425,
    y1: 5.212,
    y2: 9.053,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.11,
    stopColor: "#F8ADFA"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.708,
    stopColor: "#A86EDD",
    stopOpacity: 0
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot20Color);

export { ForwardRef as default };
