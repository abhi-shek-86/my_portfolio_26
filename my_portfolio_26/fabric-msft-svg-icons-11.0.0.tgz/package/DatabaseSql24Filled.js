import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseSql24Filled = function SvgDatabaseSql24Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M12 10c4.418 0 8-1.79 8-4s-3.582-4-8-4-8 1.791-8 4 3.582 4 8 4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M18.328 10.17A7.6 7.6 0 0 0 20 9.055v5.842a2 2 0 0 0-.839.64A3.4 3.4 0 0 0 17 14.75c-.848 0-1.627.319-2.23.843a3.6 3.6 0 0 0-1.132-.65 3.7 3.7 0 0 0-1.149-.187 4 4 0 0 0-.579.012 3.5 3.5 0 0 0-.723.14c-.42.135-.799.357-1.12.644a3.2 3.2 0 0 0-.753 1.01c-.18.379-.284.786-.31 1.2L9 17.825v.064c0 .67.212 1.206.5 1.621l-.002.004a2 2 0 0 0-.275 2.238C6.173 21.188 4 19.72 4 18V9.054a7.6 7.6 0 0 0 1.672 1.117C7.37 11.019 9.608 11.5 12 11.5s4.63-.482 6.328-1.33m3.172 6.58a.75.75 0 0 0-1.5 0v4.5c0 .415.336.75.75.75H23a.75.75 0 0 0 0-1.5h-1.5z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M13.234 16.127a2.5 2.5 0 0 0-.797-.12 2.4 2.4 0 0 0-.41.006 2.3 2.3 0 0 0-.457.086c-.248.08-.475.212-.668.385a2 2 0 0 0-.459.616c-.11.233-.175.485-.191.742l-.002.024v.024c0 .714.423 1.167.81 1.42.35.23.746.35.945.41l.085.025c.218.066.377.114.505.198.058.038.08.066.09.082.006.01.021.036.021.105 0 .186-.057.247-.088.273-.048.04-.16.098-.368.098-.34 0-.587-.082-.755-.23a.75.75 0 1 0-.99 1.127c.533.469 1.185.602 1.745.602.464 0 .954-.125 1.342-.456.405-.346.614-.845.614-1.414 0-.71-.379-1.173-.788-1.441-.325-.213-.701-.324-.892-.38l-.058-.017c-.22-.067-.429-.133-.586-.236a.4.4 0 0 1-.117-.104.1.1 0 0 1-.014-.042.5.5 0 0 1 .047-.166.5.5 0 0 1 .105-.143.4.4 0 0 1 .124-.073 1.4 1.4 0 0 1 .282-.027h.002l.042.005h.045c.19 0 .286.018.351.04a.9.9 0 0 1 .272.17.75.75 0 0 0 .958-1.154 2.3 2.3 0 0 0-.745-.435M17 16a2.17 2.17 0 0 0-1.621.747 2.55 2.55 0 0 0-.629 1.691v1.125c0 .62.218 1.23.629 1.692A2.17 2.17 0 0 0 17 22c.373 0 .73-.1 1.046-.278l.254.191a.75.75 0 0 0 .9-1.2l-.16-.12c.138-.323.21-.675.21-1.03v-1.125c0-.62-.218-1.23-.629-1.691A2.17 2.17 0 0 0 17 16m.45 3.4a.75.75 0 0 0-1.174.405 1 1 0 0 1-.026-.242v-1.125c0-.275.098-.524.25-.695a.67.67 0 0 1 .5-.242c.169 0 .35.074.5.242.152.17.25.42.25.695v1.125q0 .03-.002.061l-.298-.223Z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseSql24Filled);

export { ForwardRef as default };
