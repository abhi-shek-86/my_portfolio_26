import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseSql32Regular = function SvgDatabaseSql32Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M27 7c0-2.76-4.925-5-11-5S5 4.24 5 7v18c0 1.995 2.568 3.716 6.284 4.519a3 3 0 0 1-.744-2.253 12 12 0 0 1-1.49-.55C7.192 25.87 7 25.114 7 25V9.876c1.99 1.285 5.28 2.125 9 2.125s7.01-.84 9-2.125v10.296a3 3 0 0 1 2 0zm-2 0c0 .115-.193.872-2.05 1.715-1.675.762-4.13 1.286-6.95 1.286s-5.275-.524-6.95-1.286C7.192 7.872 7 7.115 7 7s.193-.87 2.05-1.714C10.724 4.524 13.18 4 16 4s5.275.524 6.95 1.286C24.808 6.129 25 6.886 25 7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M15.022 22.011a3.05 3.05 0 0 1 2.118.622.998.998 0 0 1-.098 1.675 1 1 0 0 1-1.121-.09 1.06 1.06 0 0 0-.771-.21l-.116.014-.115-.013a.34.34 0 0 0-.267.08.34.34 0 0 0-.106.15 1 1 0 0 0 .068.047q.327.172.687.255l.068.02c.38.091.747.235 1.088.428a2.01 2.01 0 0 1 1.021 1.76 2.11 2.11 0 0 1-.9 1.822 2.7 2.7 0 0 1-1.506.421 3.1 3.1 0 0 1-2.173-.685 1 1 0 0 1 1.261-1.553 1.1 1.1 0 0 0 .784.241h.085q.15.003.3-.029a.4.4 0 0 0 .128-.047.4.4 0 0 0 .023-.167v-.008a.4.4 0 0 0-.059-.042 1.5 1.5 0 0 0-.275-.119 5 5 0 0 0-.25-.075l-.136-.038-.034-.009a4.6 4.6 0 0 1-1.148-.46 2.01 2.01 0 0 1-1.045-1.742v-.069a2.346 2.346 0 0 1 2.489-2.179M21 22a3.07 3.07 0 0 0-2.1.82 2.82 2.82 0 0 0-.9 2.055v1.25a2.82 2.82 0 0 0 .9 2.055c.57.53 1.321.824 2.1.82a3.1 3.1 0 0 0 1.629-.46l.347.26a1 1 0 0 0 1.2-1.6l-.308-.23c.087-.273.132-.558.132-.845v-1.25a2.82 2.82 0 0 0-.9-2.055A3.07 3.07 0 0 0 21 22m-.224 3.9a1 1 0 0 0-.09 1.06 1 1 0 0 1-.416-.235.82.82 0 0 1-.27-.6v-1.25a.82.82 0 0 1 .27-.6 1.095 1.095 0 0 1 1.46 0 .82.82 0 0 1 .27.6v.72a1 1 0 0 0-1.224.306Zm5.931-3.607A1 1 0 0 1 27 23v3.994L29 27a1 1 0 1 1 0 2l-3-.008a1 1 0 0 1-1-1V23a1 1 0 0 1 1.707-.707"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseSql32Regular);

export { ForwardRef as default };
