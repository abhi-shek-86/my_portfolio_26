import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot32Filled = function SvgCopilot32Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M25.996 9c3.258 0 5.646 3.066 4.848 6.225l-2.59 10.245A6 6 0 0 1 22.438 30H15.75c-3.258 0-5.646-3.068-4.847-6.227l.196-.773h2.37a5 5 0 0 0 4.847-3.775L20.898 9zm-9.75-7c3.258 0 5.647 3.066 4.849 6.225L20.898 9h-2.366a5 5 0 0 0-4.847 3.773L11.098 23H6c-3.259 0-5.646-3.067-4.847-6.227L3.744 6.528A6 6 0 0 1 9.561 2z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot32Filled);

export { ForwardRef as default };
