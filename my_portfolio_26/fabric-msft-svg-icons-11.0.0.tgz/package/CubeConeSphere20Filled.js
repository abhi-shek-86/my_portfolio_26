import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCubeConeSphere20Filled = function SvgCubeConeSphere20Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "m13.283 4.715-.018.01-.01.005c-.26.145-.47.367-.6.636l-3.3 6.684-.005.008a4 4 0 0 0-.24.624v.002q-.11.38-.109.775c-.003.475.125.942.372 1.348l.001.004q.17.277.384.521L7.17 16.624a1.53 1.53 0 0 1-1.344 0l-3-1.5a1.4 1.4 0 0 1-.6-.555A1.57 1.57 0 0 1 2 13.78v-3.765c0-.278.075-.551.22-.789a1.4 1.4 0 0 1 .609-.555l3-1.5q.084-.04.172-.072L6 7a4 4 0 0 1 7.283-2.285M6.5 10.835l-1.773-.88A.505.505 0 0 0 4 10.4q.007.135.073.254a.45.45 0 0 0 .2.188L6 11.71v2.19a.5.5 0 1 0 1 0v-2.19l1.73-.867a.45.45 0 0 0 .2-.188A.5.5 0 0 0 9 10.4a.505.505 0 0 0-.727-.448z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M17.75 12.492q.11.226.18.469.07.244.07.5c0 .292-.081.579-.235.828a2.8 2.8 0 0 1-.585.68c-.237.2-.5.37-.782.5q-.39.183-.8.32a5.2 5.2 0 0 1-1.524.227l-.039-.003-.039-.002q-.02 0-.039.002l-.039.003c-.516 0-1.03-.077-1.524-.227a7 7 0 0 1-.8-.32 3.4 3.4 0 0 1-.782-.5 2.8 2.8 0 0 1-.585-.68A1.57 1.57 0 0 1 10 13.46q0-.256.07-.5.07-.243.18-.47l3.305-6.687a.45.45 0 0 1 .187-.2.5.5 0 0 1 .25-.063H14l.008-.003c.087 0 .173.021.25.063a.45.45 0 0 1 .187.2l3.305 6.69Z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCubeConeSphere20Filled);

export { ForwardRef as default };
