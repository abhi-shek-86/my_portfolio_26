import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot16Regular = function SvgCopilot16Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M12.529 4.462a.5.5 0 0 1 .638-.305 2.753 2.753 0 0 1 1.74 3.285l-1.382 5.314A3 3 0 0 1 10.62 15H6.998a2.75 2.75 0 0 1-2.66-3.444l.047-.182c.076-.213.244-.374.484-.374h2.703a1.75 1.75 0 0 0 1.693-1.31l.863-3.316a.5.5 0 0 1 .968.252l-.863 3.316A2.75 2.75 0 0 1 7.572 12H5.267a1.75 1.75 0 0 0 1.731 2h3.623a2 2 0 0 0 1.936-1.496L13.94 7.19a1.75 1.75 0 0 0-1.107-2.09.5.5 0 0 1-.304-.638M9.002 1c1.8 0 3.116 1.7 2.662 3.442l-.047.184a.5.5 0 0 1-.485.374H8.434a1.75 1.75 0 0 0-1.693 1.309l-.873 3.343A.5.5 0 0 1 4.9 9.4l.873-3.343A2.75 2.75 0 0 1 8.434 4h2.3a1.75 1.75 0 0 0-1.732-2H5.384A2 2 0 0 0 3.45 3.495L2.062 8.81a1.75 1.75 0 0 0 1.078 2.08.5.5 0 0 1-.35.937 2.75 2.75 0 0 1-1.696-3.27l1.387-5.314A3 3 0 0 1 5.384 1z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot16Regular);

export { ForwardRef as default };
