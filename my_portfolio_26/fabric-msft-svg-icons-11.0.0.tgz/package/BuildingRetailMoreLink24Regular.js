import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgBuildingRetailMoreLink24Regular = function SvgBuildingRetailMoreLink24Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M6.274 4c-.341 0-.667.139-.903.385l-2.95 3.077C1.505 8.415 2.18 10 3.502 10h.492v7.202a3.25 3.25 0 0 0 3.25 3.25h4.99a4.8 4.8 0 0 1-.926-1.5H7.245a1.75 1.75 0 0 1-1.75-1.75V10h13v2.5h.75q.382 0 .75.059V10h.491c1.321 0 1.997-1.585 1.083-2.538l-2.951-3.077A1.25 1.25 0 0 0 17.716 4H6.273Zm14.212 4.5H3.503l2.877-3h11.23z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12.591 13.697a1 1 0 1 0-1.184 1.612 4.8 4.8 0 0 1 1.184-1.612m-3.096.803a1 1 0 1 1-2 0 1 1 0 0 1 2 0m13.499 2.75a3.75 3.75 0 0 0-3.75-3.75l-.101.007A.75.75 0 0 0 19.244 15l.155.005a2.25 2.25 0 0 1-.155 4.495l-.003.005-.102.007a.75.75 0 0 0 .109 1.493V21l.199-.005a3.75 3.75 0 0 0 3.547-3.745m-6.5-3a.75.75 0 0 0-.75-.75l-.199.005a3.75 3.75 0 0 0 .2 7.495l.101-.007a.75.75 0 0 0-.101-1.493l-.154-.005A2.25 2.25 0 0 1 15.745 15l.101-.007a.75.75 0 0 0 .648-.743"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M19.994 17.25a.75.75 0 0 0-.75-.75h-3.5l-.101.007A.75.75 0 0 0 15.744 18h3.5l.102-.007a.75.75 0 0 0 .648-.743"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgBuildingRetailMoreLink24Regular);

export { ForwardRef as default };
