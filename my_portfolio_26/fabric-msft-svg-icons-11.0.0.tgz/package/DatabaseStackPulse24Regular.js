import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseStackPulse24Regular = function SvgDatabaseStackPulse24Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M4.774 4.22C4.315 4.707 4 5.31 4 6v12c0 .69.315 1.293.774 1.78.455.482 1.079.883 1.793 1.203C7.996 21.623 9.917 22 12 22q.4 0 .792-.018a6.5 6.5 0 0 1-1.061-1.484c-1.811-.031-3.412-.374-4.55-.884-.6-.268-1.037-.568-1.316-.864-.275-.29-.365-.543-.365-.75v-3.608c.32.22.68.417 1.067.59 1.239.556 2.848.913 4.612.998a6.5 6.5 0 0 1 .554-1.482c-1.812-.031-3.413-.373-4.553-.884-.598-.269-1.036-.568-1.315-.864-.275-.29-.365-.543-.365-.75V8.392c.32.22.68.417 1.067.59C7.996 9.623 9.917 10 12 10s4.004-.377 5.433-1.018c.386-.173.746-.37 1.067-.59v2.684a6.5 6.5 0 0 1 1.5.422V6c0-.69-.315-1.293-.774-1.78-.455-.482-1.079-.883-1.793-1.202C16.004 2.377 14.083 2 12 2s-4.004.377-5.433 1.018c-.714.32-1.338.72-1.793 1.202m1.091 2.53C5.59 6.46 5.5 6.207 5.5 6s.09-.46.365-.75c.279-.296.717-.596 1.315-.864C8.375 3.851 10.08 3.5 12 3.5s3.625.35 4.82.886c.598.268 1.036.568 1.315.864.275.29.365.543.365.75s-.09.46-.365.75c-.279.296-.717.596-1.315.864-1.195.535-2.899.886-4.82.886s-3.625-.35-4.82-.886c-.598-.268-1.036-.568-1.315-.864"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M23 17.5a5.5 5.5 0 1 0-11 0 5.5 5.5 0 0 0 11 0m-6.985-3a.5.5 0 0 1 .46.342l1.053 3.16 1.004-2.678a.5.5 0 0 1 .915-.048L20.31 17H21a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.447-.276l-.487-.975-1.098 2.927a.5.5 0 0 1-.942-.018l-1.069-3.205-.493 1.233A.5.5 0 0 1 15 18h-1a.5.5 0 0 1 0-1h.662l.874-2.186a.5.5 0 0 1 .479-.314"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseStackPulse24Regular);

export { ForwardRef as default };
