import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataEngineering28Regular = function SvgDataEngineering28Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 28,
    height: 28,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M15.34 16.7c5.12-3.02 7.84-7.11 7.84-7.11l.02-.01c1.01-1.49 2.85-.48 2.85 1.11v6.53c-.03.57-.28 1.11-.68 1.51l-6.74 6.72c-.36.36-.84.57-1.33.57H9.32c-.53 0-1.03-.22-1.4-.61l-5.34-5.73c-.35-.37-.58-.94-.58-1.47V9.93c0-.54.21-1.06.58-1.44l5.75-5.91C8.7 2.21 9.19 2 9.7 2h9.34c.73 0 1.21.74.86 1.41-.84 1.62-2.55 4.34-5.5 6.66-.97.77-1.8 1.45-2.53 2.07l1.518 2.399c.71 1.12.943 1.488 1.952 2.161m7.76 1.65c.75-.27 1.3-.674 1.43-.974a.6.6 0 0 0 .05-.206v-6.48c0-.08-.03-.15-.06-.2a.5.5 0 0 0-.08-.09c-.16.23-.71.98-1.03 1.37-.64.77-1.58 1.81-2.81 2.93-1.06.96-2.36 1.97-3.86 2.92 0 0 .39.24 1.02.55 1.85.92 3.97.69 5.34.18m-19.49.21 1.58 1.7c.01-.45.07-.89.16-1.33.29-1.4.68-2.7 1.92-4.3 1.16-1.51 3.07-3.27 6.26-5.78 2.26-1.78 3.74-3.82 4.62-5.32H9.7c-.13 0-.25.05-.34.14L3.61 9.59a.5.5 0 0 0-.14.35v8.27c0 .13.05.26.14.35m18.138 1.682c-1.387.187-3.052.076-4.618-.692-2.07-1.02-3.66-2.15-5.03-4.3l-1.34-2.12c-3.03 2.77-3.57 4.2-3.97 6.12-.25 1.21-.16 2.35.61 3.37l1.57 1.7c.09.1.21.15.34.15h7.99c.08 0 .21-.04.32-.15z",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataEngineering28Regular);

export { ForwardRef as default };
