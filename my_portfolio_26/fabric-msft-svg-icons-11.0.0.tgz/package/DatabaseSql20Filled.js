import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseSql20Filled = function SvgDatabaseSql20Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M10 8c3.314 0 6-1.343 6-3 0-1.656-2.686-3-6-3S4 3.344 4 5c0 1.657 2.686 3 6 3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M14.69 8.016A5.5 5.5 0 0 0 16 7.121V12H7v5.598C5.207 17.079 4 16.11 4 15V7.12c.383.362.84.66 1.31.895C6.562 8.641 8.222 9 10 9s3.438-.359 4.69-.985Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M11.206 13.435a2.14 2.14 0 0 0-1.51-.437 1.58 1.58 0 0 0-1.695 1.468L8 14.484v.017c0 .578.364.935.693 1.135.306.187.657.286.848.34l.085.023c.201.057.388.109.54.202.14.085.192.166.192.3 0 .255-.084.34-.152.387-.1.068-.272.113-.506.113h-.021l-.022.002a1.17 1.17 0 0 1-.84-.26.5.5 0 1 0-.633.774c.431.353.982.526 1.537.484.32-.003.717-.06 1.05-.287.371-.254.587-.668.587-1.213 0-.582-.33-.946-.671-1.154-.28-.17-.606-.26-.792-.311l-.06-.016c-.206-.059-.44-.126-.622-.238-.164-.1-.208-.182-.213-.266a.58.58 0 0 1 .644-.518l.058.006.058-.007a1.14 1.14 0 0 1 .834.23.5.5 0 0 0 .612-.792M14 13a2 2 0 0 0-2 2v1a2 2 0 0 0 3.25 1.562l.45.338a.5.5 0 0 0 .6-.8l-.45-.338A2 2 0 0 0 16 16v-1a2 2 0 0 0-2-2m.3 2.6a.5.5 0 0 0-.6.8l.693.52A1 1 0 0 1 13 16v-1a1 1 0 0 1 2 0v1q0 .06-.007.12zm3.2-2.6a.5.5 0 0 1 .5.5V17h1.5a.5.5 0 1 1 0 1h-2a.5.5 0 0 1-.5-.5v-4a.5.5 0 0 1 .5-.5"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseSql20Filled);

export { ForwardRef as default };
