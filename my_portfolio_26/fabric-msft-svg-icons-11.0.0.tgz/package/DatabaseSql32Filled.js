import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseSql32Filled = function SvgDatabaseSql32Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M5 7c0-2.76 4.925-5 11-5s11 2.24 11 5c0 2.762-4.925 5-11 5S5 9.763 5 7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 14c3.256 0 6.3-.595 8.606-1.643.823-.374 1.668-.865 2.394-1.48v9.295a3 3 0 0 0-3.121.707l-.009.009a5.1 5.1 0 0 0-5.743 0A5.07 5.07 0 0 0 15.268 20c-.061 0-.183.003-.277.005l-.123.003a4.346 4.346 0 0 0-4.343 4.075v.178c-.002.608.14 1.209.412 1.753a3.01 3.01 0 0 0 .347 3.505C7.568 28.716 5 26.995 5 25V10.876c.726.615 1.571 1.106 2.394 1.48C9.7 13.405 12.744 14 16 14"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M15.022 22.011a3.05 3.05 0 0 1 2.118.622.998.998 0 0 1-.098 1.675 1 1 0 0 1-1.121-.09 1.06 1.06 0 0 0-.771-.21l-.116.014-.115-.013a.34.34 0 0 0-.267.08.34.34 0 0 0-.106.15 1 1 0 0 0 .068.047q.327.172.687.255l.068.02c.38.091.747.235 1.088.428a2.01 2.01 0 0 1 1.021 1.76 2.11 2.11 0 0 1-.9 1.822 2.7 2.7 0 0 1-1.506.421 3.1 3.1 0 0 1-2.173-.685 1 1 0 0 1 1.261-1.553 1.1 1.1 0 0 0 .784.241h.085q.15.003.3-.029a.4.4 0 0 0 .128-.047.4.4 0 0 0 .023-.167v-.008a.4.4 0 0 0-.059-.042 1.5 1.5 0 0 0-.275-.119 5 5 0 0 0-.25-.075l-.136-.038-.034-.009a4.6 4.6 0 0 1-1.148-.46 2.01 2.01 0 0 1-1.045-1.742v-.069a2.346 2.346 0 0 1 2.489-2.179m3.878.809A3.07 3.07 0 0 1 21 22c.779-.003 1.53.29 2.1.82a2.82 2.82 0 0 1 .9 2.055v1.25c0 .287-.045.572-.132.845l.308.23a1 1 0 1 1-1.2 1.6l-.347-.26A3.1 3.1 0 0 1 21 29a3.07 3.07 0 0 1-2.1-.82 2.82 2.82 0 0 1-.9-2.055v-1.25a2.82 2.82 0 0 1 .9-2.055m2.434 2.71a1 1 0 0 1 .666.064v-.719a.82.82 0 0 0-.27-.6 1.095 1.095 0 0 0-1.46 0 .82.82 0 0 0-.27.6v1.25a.82.82 0 0 0 .27.6c.118.11.26.19.416.234a1 1 0 0 1 .09-1.058 1 1 0 0 1 .558-.37ZM27 23a1 1 0 0 0-2 0v4.992a1 1 0 0 0 1 1L29 29a1 1 0 0 0 0-2l-2-.006z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseSql32Filled);

export { ForwardRef as default };
