import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopyJob64Item = function SvgCopyJob64Item(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 64,
    height: 64,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#ia49f9e-a)",
    d: "M6 13a7 7 0 0 1 7-7h38a7 7 0 0 1 7 7v38a7 7 0 0 1-7 7H13a7 7 0 0 1-7-7z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ia49f9e-b)",
    fillOpacity: 0.2,
    d: "M6 13a7 7 0 0 1 7-7h38a7 7 0 0 1 7 7v38a7 7 0 0 1-7 7H13a7 7 0 0 1-7-7z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ia49f9e-c)",
    fillRule: "evenodd",
    d: "M51 7H13a6 6 0 0 0-6 6v38a6 6 0 0 0 6 6h38a6 6 0 0 0 6-6V13a6 6 0 0 0-6-6M13 6a7 7 0 0 0-7 7v38a7 7 0 0 0 7 7h38a7 7 0 0 0 7-7V13a7 7 0 0 0-7-7z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ia49f9e-d)",
    fillRule: "evenodd",
    d: "M27.05 18.5c.127-.642.492-1.21.98-1.69.61-.597 1.453-1.101 2.435-1.508C32.43 14.487 35.095 14 38 14c2.904 0 5.569.487 7.535 1.302.982.407 1.825.91 2.434 1.508.613.6 1.031 1.34 1.031 2.19v20c0 .85-.418 1.59-1.03 2.19-.61.597-1.453 1.101-2.435 1.508C43.57 43.513 40.905 44 38 44c-1.407 0-2.758-.114-4-.325V45.5c0 2.485-3.806 4.5-8.5 4.5S17 47.985 17 45.5v-9.763a8 8 0 0 0 1.788 1.27c1.794.95 4.17 1.493 6.712 1.493s4.918-.542 6.712-1.492A8 8 0 0 0 34 35.738v6.414c1.214.222 2.567.348 4 .348 2.757 0 5.217-.465 6.96-1.188.874-.362 1.532-.774 1.96-1.193.425-.417.58-.795.58-1.119V21.597c-.546.423-1.215.79-1.965 1.101C43.57 23.513 40.905 24 38 24c-2.904 0-5.569-.487-7.535-1.302-.748-.31-1.417-.677-1.962-1.098v5.162a16 16 0 0 0-1.5-.198v-7.441a3 3 0 0 1 0-.246V18.5h.046Zm1.453.423c.023-.307.186-.658.578-1.042.427-.42 1.085-.831 1.958-1.193C32.783 15.965 35.243 15.5 38 15.5s5.217.465 6.96 1.188c.874.362 1.532.774 1.96 1.193.425.417.58.795.58 1.119v.006c-.002.323-.158.698-.58 1.113-.428.42-1.086.831-1.96 1.193-1.743.723-4.203 1.188-6.96 1.188s-5.217-.465-6.96-1.188c-.874-.362-1.532-.774-1.96-1.193-.391-.384-.554-.735-.577-1.042z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ia49f9e-e)",
    d: "M33.819 31.57C33.008 29.531 29.591 28 25.5 28c-4.694 0-8.5 2.015-8.5 4.5s3.806 4.5 8.5 4.5 8.5-2.015 8.5-4.5c0-.319-.063-.63-.181-.93"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ia49f9e-f)",
    d: "M19.25 22.25A2.75 2.75 0 0 0 16.5 25v3.25a.75.75 0 0 1-1.5 0V25a4.25 4.25 0 0 1 4.25-4.25h2.235l-2.265-2.265a.75.75 0 1 1 1.06-1.06l3.5 3.5a.75.75 0 0 1 0 1.06l-3.5 3.5a.75.75 0 1 1-1.06-1.06l2.174-2.175z"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "ia49f9e-a",
    x1: 20.444,
    x2: 27.022,
    y1: 6,
    y2: 58.622,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#EBEBEB"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ia49f9e-c",
    x1: 22.792,
    x2: 29.793,
    y1: 6,
    y2: 58.511,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#BBB"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#888"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ia49f9e-d",
    x1: 15,
    x2: 50.941,
    y1: 14,
    y2: 47.944,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ia49f9e-e",
    x1: 15,
    x2: 50.941,
    y1: 14,
    y2: 47.944,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ia49f9e-f",
    x1: 15,
    x2: 50.941,
    y1: 14,
    y2: 47.944,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "ia49f9e-b",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(27.4444 41.16672 -35.62501 23.74995 22.61 19.541)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.177,
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#B8B8B8"
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopyJob64Item);

export { ForwardRef as default };
