import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCustomStreamingConnector32Item = function SvgCustomStreamingConnector32Item(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i51d05b-i9ac469-paint0_linear_62220_773)",
    d: "M3 6.5A3.5 3.5 0 0 1 6.5 3h19A3.5 3.5 0 0 1 29 6.5v19a3.5 3.5 0 0 1-3.5 3.5h-19A3.5 3.5 0 0 1 3 25.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i51d05b-i9ac469-paint1_radial_62220_773)",
    fillOpacity: 0.2,
    d: "M3 6.5A3.5 3.5 0 0 1 6.5 3h19A3.5 3.5 0 0 1 29 6.5v19a3.5 3.5 0 0 1-3.5 3.5h-19A3.5 3.5 0 0 1 3 25.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i51d05b-i9ac469-paint2_linear_62220_773)",
    fillRule: "evenodd",
    d: "M25.5 4h-19A2.5 2.5 0 0 0 4 6.5v19A2.5 2.5 0 0 0 6.5 28h19a2.5 2.5 0 0 0 2.5-2.5v-19A2.5 2.5 0 0 0 25.5 4m-19-1A3.5 3.5 0 0 0 3 6.5v19A3.5 3.5 0 0 0 6.5 29h19a3.5 3.5 0 0 0 3.5-3.5v-19A3.5 3.5 0 0 0 25.5 3z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i51d05b-i9ac469-paint3_linear_62220_773)",
    d: "M14.013 14.775a1.25 1.25 0 0 0-1.768 0l-.22.22A3.47 3.47 0 0 0 11 17.524c.012.756.26 1.47.71 2.059l-2.063 2.063a.5.5 0 0 0 .708.707l2.07-2.07a3.45 3.45 0 0 0 2.036.652c.938 0 1.888-.363 2.604-1.08l.131-.131a1.25 1.25 0 0 0 0-1.768l-3.182-3.182zm8.341-5.129a.5.5 0 0 0-.707 0l-2.07 2.07c-1.37-.999-3.37-.843-4.64.428l-.131.131a1.25 1.25 0 0 0 0 1.768l3.182 3.182c.243.244.563.366.884.366s.641-.122.884-.366l.22-.22a3.47 3.47 0 0 0 1.025-2.529 3.46 3.46 0 0 0-.71-2.059l2.063-2.063a.5.5 0 0 0 0-.708"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#F5F5F5",
    fillRule: "evenodd",
    d: "M28.5 19a1.5 1.5 0 0 1 1.413 2h.587a1.5 1.5 0 0 1 1.115 2.5c.207.23.344.522.377.847L32 24.5a1.5 1.5 0 0 1-1.5 1.5H29a6 6 0 0 1-6 5.996h-1.5a1.5 1.5 0 0 1-1.5-1.5l.008-.153q.022-.21.098-.398a1.5 1.5 0 0 1-1.098-1.292L19 28.5l.008-.153c.033-.325.17-.617.377-.847a1.5 1.5 0 0 1-.377-.847L19 26.5l.008-.153A1.5 1.5 0 0 1 20.5 25H22a6 6 0 0 1 6-6z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i51d05b-i9ac469-paint4_linear_62220_773)",
    d: "M30.5 24a.5.5 0 0 1 0 1h-1.64a.86.86 0 0 0-.86.86l-.003.023.003.023v.09a5 5 0 0 1-5 5h-1.5a.5.5 0 0 1 0-1H23a4 4 0 0 0 4-4v-.09l.002-.023-.002-.024A1.86 1.86 0 0 1 28.86 24z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i51d05b-i9ac469-paint5_linear_62220_773)",
    d: "M30.5 22a.5.5 0 0 1 0 1h-2.031A2.47 2.47 0 0 0 26 25.469v.031a3.5 3.5 0 0 1-3.5 3.5h-2a.5.5 0 0 1 0-1h2a2.5 2.5 0 0 0 2.5-2.5v-.074l.001-.018A3.47 3.47 0 0 1 28.469 22z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i51d05b-i9ac469-paint6_linear_62220_773)",
    d: "M28.5 20a.5.5 0 0 1 0 1H28a4 4 0 0 0-4 4v.469l-.001.008.001.007c0 .837-.679 1.516-1.516 1.516H20.5a.5.5 0 0 1 0-1h1.984c.285 0 .516-.23.516-.516V25a5 5 0 0 1 5-5z"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i51d05b-i9ac469-paint0_linear_62220_773",
    x1: 10.222,
    x2: 13.511,
    y1: 3,
    y2: 29.311,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#EBEBEB"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i51d05b-i9ac469-paint1_radial_62220_773",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(13.72224 20.58334 -17.81253 11.87503 11.306 9.77)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.177,
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#B8B8B8"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i51d05b-i9ac469-paint2_linear_62220_773",
    x1: 11.396,
    x2: 14.897,
    y1: 3,
    y2: 29.256,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#BBB"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#888"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i51d05b-i9ac469-paint3_linear_62220_773",
    x1: 9.501,
    x2: 22.5,
    y1: 9.5,
    y2: 22.499,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i51d05b-i9ac469-paint4_linear_62220_773",
    x1: 20,
    x2: 30.996,
    y1: 20,
    y2: 31,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i51d05b-i9ac469-paint5_linear_62220_773",
    x1: 20,
    x2: 30.996,
    y1: 20,
    y2: 31,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i51d05b-i9ac469-paint6_linear_62220_773",
    x1: 20,
    x2: 30.996,
    y1: 20,
    y2: 31,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCustomStreamingConnector32Item);

export { ForwardRef as default };
