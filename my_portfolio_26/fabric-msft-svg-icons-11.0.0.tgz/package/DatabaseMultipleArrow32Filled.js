import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseMultipleArrow32Filled = function SvgDatabaseMultipleArrow32Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M19 28c0 1.657-3.134 3-7 3-2.591 0-4.853-.603-6.063-1.5C5.34 29.059 5 28.546 5 28v-7.327c.436.33.936.603 1.459.827 1.494.64 3.455 1 5.541 1 1.234 0 2.424-.126 3.5-.361.726-.16 1.4-.368 2-.621l.041-.018A7 7 0 0 0 19 20.673z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M31 25c0 2.708-4.735 4.913-10.648 4.997A3.47 3.47 0 0 0 21 28V17.76l-.008.006c-.114-1.71-1.47-2.8-2.537-3.38a9 9 0 0 0-1.174-.528c.881.094 1.792.142 2.719.142 3.256 0 6.3-.596 8.605-1.644.824-.374 1.669-.865 2.395-1.48z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 15c1.275 0 2.47.146 3.5.401.772.192 1.45.444 2 .743.94.51 1.5 1.155 1.5 1.856 0 .7-.56 1.346-1.5 1.856-.55.299-1.228.551-2 .743-1.03.255-2.225.401-3.5.401-3.866 0-7-1.343-7-3s3.134-3 7-3M5.293 2.293a1 1 0 0 1 1.414 0l3 3a1 1 0 0 1 .249.414 1 1 0 0 1 .028.127Q10 5.916 10 6a1 1 0 0 1-.031.24l-.013.051a1 1 0 0 1-.249.416l-3 3a1 1 0 0 1-1.414-1.414L6.586 7H5.5c-.875 0-1.46.35-1.852.86C3.234 8.398 3 9.17 3 10v4a1 1 0 0 1-2 0v-4c0-1.17.324-2.399 1.063-3.36C2.826 5.65 3.992 5 5.5 5h1.086L5.293 3.707a1 1 0 0 1 0-1.414M9 10.876c.726.615 1.571 1.106 2.395 1.48.56.255 1.166.484 1.807.683A18 18 0 0 0 12 13c-1.039 0-2.052.086-3 .253zM20 2c6.075 0 11 2.239 11 5s-4.925 5-11 5c-4.371 0-8.147-1.16-9.92-2.838l1.041-1.04a3 3 0 0 0 .102-4.136C13.23 2.78 16.415 2 20 2"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseMultipleArrow32Filled);

export { ForwardRef as default };
