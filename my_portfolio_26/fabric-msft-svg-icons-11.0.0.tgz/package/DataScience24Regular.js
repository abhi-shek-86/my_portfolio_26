import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataScience24Regular = function SvgDataScience24Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "m4.833 19.58 6.863 2.387c.229.057.47.041.687-.044l7.152-3.062a.79.79 0 0 0 .281-1.244l-3.028-3.46 4.03-6.182.008-.012c.224-.36.34-.776.34-1.2 0-.92-.546-1.749-1.386-2.102l-.038-.016-6.894-2.466a2.6 2.6 0 0 0-.933-.175c-.333 0-.638.065-.903.16l-6.36 2.184A1.5 1.5 0 0 0 3.8 6.44a1 1 0 0 0 .064.13l3.85 5.669-3.676 3.701-.035.04a2.29 2.29 0 0 0 .83 3.599Zm10.928-6.596 3.792-5.815a.77.77 0 0 0 .114-.406.78.78 0 0 0-.47-.72l-6.877-2.46a1.1 1.1 0 0 0-.405-.08c-.14 0-.277.029-.404.076L5.139 5.767l6.092 2.905a1.3 1.3 0 0 1 .454.43l.011.019.022.037c.09.164.14.352.14.556 0 .295-.104.56-.281.766l-3.004 3.024-3.434 3.456a.79.79 0 0 0 .278 1.238l5.656 1.978z",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataScience24Regular);

export { ForwardRef as default };
