import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot24Regular = function SvgCopilot24Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M18.75 6c2.765 0 4.793 2.603 4.115 5.284l-1.848 7.318A4.5 4.5 0 0 1 16.653 22h-5.276a3.962 3.962 0 0 1-3.84-4.934c.11-.322.365-.566.726-.566h2.09a2.75 2.75 0 0 0 2.668-2.076l1.226-4.857a.75.75 0 0 1 1.454.369l-1.226 4.855A4.25 4.25 0 0 1 10.354 18H8.915a2.463 2.463 0 0 0 2.462 2.5h5.276a3 3 0 0 0 2.909-2.266l1.85-7.318A2.745 2.745 0 0 0 18.75 7.5a.75.75 0 0 1 0-1.5m-6.133-4a3.963 3.963 0 0 1 3.842 4.934.75.75 0 0 1-.727.566h-2.088a2.75 2.75 0 0 0-2.666 2.075l-1.229 4.857a.75.75 0 0 1-1.454-.369l1.228-4.855A4.25 4.25 0 0 1 13.643 6h1.438a2.465 2.465 0 0 0-2.464-2.5H7.344a3 3 0 0 0-2.908 2.265l-1.85 7.313A2.748 2.748 0 0 0 5.25 16.5a.75.75 0 0 1 0 1.5c-2.769 0-4.797-2.606-4.118-5.29l1.85-7.314A4.5 4.5 0 0 1 7.343 2z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot24Regular);

export { ForwardRef as default };
