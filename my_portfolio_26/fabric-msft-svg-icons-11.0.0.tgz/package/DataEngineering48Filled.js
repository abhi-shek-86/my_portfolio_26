import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataEngineering48Filled = function SvgDataEngineering48Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 48,
    height: 48,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M4 17.23v13.8c0 .67.19 1.33.55 1.88.12.19.26.37.41.54l2.41 2.59c-.12-1.45.1-3.02.92-4.6 1.83-3.54 4.85-5.81 8.07-7.97 1.088-.73 2.792-1.882 4.465-3.1 0 0 2.435-1.81 2.485-1.85.44-.33.89-.68 1.36-1.06 4.92-3.86 7.77-8.4 9.16-11.1.43-.83.09-1.74-.62-2.14-.22-.14-.5-.22-.8-.22H16.83c-.85 0-1.67.35-2.28.97l-8.14 8.37-1.44 1.48c-.62.64-.97 1.51-.97 2.41m31.45 22.18 3.49-3.49c-2.12-.05-4.08-.45-7.75-2.26-2.47-1.22-4.93-4.07-6.82-6.73l-.28-.39c-.45-.65-.87-1.28-1.25-1.86l-1.15-1.82a147 147 0 0 1-3.848 2.67l-.77.52c-.414.279-.778.524-1.102.75-.88.62-2.704 2.304-2.704 2.304-.933.964-2.315 2.594-2.806 3.556-1.03 2-.71 4.03.09 5.83.39.89.88 1.65 1.26 2.18.19.27.46.6.46.6l1.6 1.72s.09.07.13.11c.28.27.59.49.94.64.36.16.74.23 1.13.25.02 0 .13.01.13.01h13.3c.82 0 1.61-.36 2.21-.94l3.73-3.67.01.01zm-3.21-8.05c-1.41-.7-2.93-2.19-4.34-3.9 7.44-4.88 11.4-10.81 11.4-10.81 1.69-2.48 4.76-.8 4.76 1.85v10.9c-.05.94-.46 1.84-1.13 2.51l-.75.74c-.31.3-1.3.76-3.15.73-1.77-.04-4.33-.8-6.79-2.02",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataEngineering48Filled);

export { ForwardRef as default };
