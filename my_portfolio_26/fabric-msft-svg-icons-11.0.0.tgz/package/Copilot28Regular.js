import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot28Regular = function SvgCopilot28Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 28,
    height: 28,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M22.249 7c3.095 0 5.363 2.912 4.606 5.913l-2.353 9.312A5 5 0 0 1 19.654 26h-6.152c-3.1 0-5.357-2.938-4.6-5.934.11-.322.366-.566.727-.566h2.47a3.25 3.25 0 0 0 3.151-2.454l1.637-6.478a.751.751 0 0 1 1.454.367l-1.636 6.478A4.75 4.75 0 0 1 12.1 21h-1.836c-.138 1.845 1.32 3.5 3.238 3.5h6.152a3.5 3.5 0 0 0 3.394-2.643l2.352-9.311A3.25 3.25 0 0 0 22.25 8.5h-.499a.75.75 0 0 1 0-1.5zm-7.75-5c3.1 0 5.357 2.938 4.6 5.934a.75.75 0 0 1-.727.566h-2.467a3.25 3.25 0 0 0-3.151 2.453l-1.639 6.48a.75.75 0 0 1-1.454-.369l1.639-6.479A4.75 4.75 0 0 1 15.905 7h1.832c.137-1.845-1.32-3.5-3.238-3.5h-6.15a3.5 3.5 0 0 0-3.392 2.642l-2.355 9.311a3.25 3.25 0 0 0 3.15 4.047h.498a.75.75 0 0 1 0 1.5h-.498c-3.096 0-5.364-2.914-4.605-5.915l2.355-9.312A5 5 0 0 1 8.35 2z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot28Regular);

export { ForwardRef as default };
