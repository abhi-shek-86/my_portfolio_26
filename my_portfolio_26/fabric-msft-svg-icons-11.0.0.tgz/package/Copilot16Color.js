import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot16Color = function SvgCopilot16Color(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i4fedfe-paint0_linear_42584_82288)",
    d: "M8.502 1H5.27a3 3 0 0 0-2.903 2.243L1.078 8.182A2.25 2.25 0 0 0 3.255 11h2.379L6.76 6.682A2.25 2.25 0 0 1 8.937 5h1.435l.308-1.183A2.25 2.25 0 0 0 8.502 1"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i4fedfe-paint1_radial_42584_82288)",
    d: "M8.502 1H5.27a3 3 0 0 0-2.903 2.243L1.078 8.182A2.25 2.25 0 0 0 3.255 11h2.379L6.76 6.682A2.25 2.25 0 0 1 8.937 5h1.435l.308-1.183A2.25 2.25 0 0 0 8.502 1"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i4fedfe-paint2_linear_42584_82288)",
    d: "M8.502 1H5.27a3 3 0 0 0-2.903 2.243L1.078 8.182A2.25 2.25 0 0 0 3.255 11h2.379L6.76 6.682A2.25 2.25 0 0 1 8.937 5h1.435l.308-1.183A2.25 2.25 0 0 0 8.502 1"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i4fedfe-paint3_radial_42584_82288)",
    d: "m13.642 12.755 1.285-4.938A2.25 2.25 0 0 0 12.749 5h-2.377L9.249 9.317A2.25 2.25 0 0 1 7.07 11H5.633l-.308 1.182A2.25 2.25 0 0 0 7.502 15h3.237a3 3 0 0 0 2.903-2.245"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i4fedfe-paint4_linear_42584_82288)",
    d: "m13.642 12.755 1.285-4.938A2.25 2.25 0 0 0 12.749 5h-2.377L9.249 9.317A2.25 2.25 0 0 1 7.07 11H5.633l-.308 1.182A2.25 2.25 0 0 0 7.502 15h3.237a3 3 0 0 0 2.903-2.245"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i4fedfe-paint0_linear_42584_82288",
    x1: 4.399,
    x2: 4.484,
    y1: 2.212,
    y2: 11.437,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.178,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD000"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i4fedfe-paint1_radial_42584_82288",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(-6.63392 11.5257 -26.4371 -9.16268 8.86 1)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.252,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD400"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i4fedfe-paint2_linear_42584_82288",
    x1: 5.309,
    x2: 5.26,
    y1: 1,
    y2: 11,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#3DCBFF"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.247,
    stopColor: "#0588F7",
    stopOpacity: 0
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i4fedfe-paint3_radial_42584_82288",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(5.39254 -12.3589 31.6176 10.6619 6.368 15.796)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.074,
    stopColor: "#FFB152"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.5,
    stopColor: "#F2598A"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.948,
    stopColor: "#8C48FF"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i4fedfe-paint4_linear_42584_82288",
    x1: 11.388,
    x2: 11.4,
    y1: 4.394,
    y2: 7.349,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.11,
    stopColor: "#F8ADFA"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.708,
    stopColor: "#A86EDD",
    stopOpacity: 0
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot16Color);

export { ForwardRef as default };
