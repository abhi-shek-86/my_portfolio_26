import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot48Filled = function SvgCopilot48Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 48,
    height: 48,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M38 14c4.561 0 7.904 4.293 6.787 8.715l-3.408 13.49A9 9 0 0 1 32.653 43H24c-4.562 0-7.904-4.294-6.786-8.717l.072-.283h2.93a7 7 0 0 0 6.786-5.285L30.72 14zM24.006 5c4.561 0 7.904 4.293 6.786 8.715L30.72 14h-2.925a7 7 0 0 0-6.786 5.283L17.287 34h-7.28c-4.562 0-7.905-4.294-6.786-8.717l3.412-13.49A9 9 0 0 1 15.36 5z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot48Filled);

export { ForwardRef as default };
