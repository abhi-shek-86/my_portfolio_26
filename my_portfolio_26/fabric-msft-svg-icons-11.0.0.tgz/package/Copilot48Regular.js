import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot48Regular = function SvgCopilot48Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 48,
    height: 48,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M36.75 12.504c5.375 0 9.315 5.059 7.998 10.27l-3.394 13.434a9 9 0 0 1-8.725 6.796h-9.626c-4.742 0-8.217-4.464-7.054-9.06.162-.544.629-.944 1.212-.944h3.052a5.75 5.75 0 0 0 5.575-4.342l2.707-10.717a1.25 1.25 0 0 1 2.424.613L28.212 29.27a8.25 8.25 0 0 1-8 6.229h-1.98c-.133 2.657 1.985 5.004 4.77 5.004h9.627a6.5 6.5 0 0 0 6.302-4.908l3.393-13.434c.918-3.632-1.828-7.158-5.574-7.158h-1.5a1.25 1.25 0 0 1 0-2.5zM24.998 5c4.742 0 8.217 4.463 7.056 9.06a1.25 1.25 0 0 1-1.212.944h-3.047a5.75 5.75 0 0 0-5.574 4.34L19.51 30.06a1.25 1.25 0 0 1-2.423-.614l2.71-10.716a8.25 8.25 0 0 1 7.998-6.226h1.975c.133-2.657-1.986-5.004-4.772-5.004h-9.62a6.5 6.5 0 0 0-6.3 4.906L5.68 25.84C4.76 29.473 7.507 33 11.254 33h1.496a1.25 1.25 0 0 1 0 2.5h-1.496c-5.377 0-9.317-5.061-7.998-10.273l3.397-13.434A9 9 0 0 1 15.38 5z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot48Regular);

export { ForwardRef as default };
