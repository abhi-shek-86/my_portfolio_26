import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopyJob32Item = function SvgCopyJob32Item(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i582d0e-a)",
    d: "M3 6.5A3.5 3.5 0 0 1 6.5 3h19A3.5 3.5 0 0 1 29 6.5v19a3.5 3.5 0 0 1-3.5 3.5h-19A3.5 3.5 0 0 1 3 25.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i582d0e-b)",
    fillOpacity: 0.2,
    d: "M3 6.5A3.5 3.5 0 0 1 6.5 3h19A3.5 3.5 0 0 1 29 6.5v19a3.5 3.5 0 0 1-3.5 3.5h-19A3.5 3.5 0 0 1 3 25.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i582d0e-c)",
    fillRule: "evenodd",
    d: "M25.5 4h-19A2.5 2.5 0 0 0 4 6.5v19A2.5 2.5 0 0 0 6.5 28h19a2.5 2.5 0 0 0 2.5-2.5v-19A2.5 2.5 0 0 0 25.5 4m-19-1A3.5 3.5 0 0 0 3 6.5v19A3.5 3.5 0 0 0 6.5 29h19a3.5 3.5 0 0 0 3.5-3.5v-19A3.5 3.5 0 0 0 25.5 3z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i582d0e-d)",
    fillRule: "evenodd",
    d: "M10 22.25v-3.752c.221.162.455.293.675.396.839.39 1.927.606 3.075.606s2.236-.215 3.075-.606c.22-.103.454-.234.675-.396v2.313c.52.12 1.114.189 1.75.189 1.117 0 2.104-.214 2.792-.538.728-.343.958-.717.958-.962v-7.431a4 4 0 0 1-.532.298c-.85.4-1.988.633-3.218.633s-2.369-.234-3.218-.633a4 4 0 0 1-.532-.299v2.108a8 8 0 0 0-1-.145V10.46c.023-.839.735-1.45 1.532-1.826.85-.4 1.988-.633 3.218-.633s2.369.234 3.218.633c.797.376 1.51.987 1.532 1.826v9.04c0 .86-.722 1.485-1.532 1.867-.85.4-1.988.633-3.218.633a9 9 0 0 1-1.75-.166v.416c0 .966-1.68 1.75-3.75 1.75S10 23.216 10 22.25m5.5-11.75c0-.245.23-.62.958-.962C17.147 9.214 18.133 9 19.25 9s2.104.214 2.792.538c.728.343.958.717.958.962s-.23.62-.958.962c-.689.324-1.675.538-2.792.538s-2.104-.214-2.792-.538c-.728-.343-.958-.717-.958-.962",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i582d0e-e)",
    d: "M10.038 16.5c.244-.795 1.633-1.418 3.362-1.492a8 8 0 0 1 1.1.027c.354.034.69.09 1 .167 1.04.256 1.789.734 1.962 1.298a.9.9 0 0 1 .038.25c0 .966-1.679 1.75-3.75 1.75S10 17.716 10 16.75q0-.127.038-.25"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i582d0e-f)",
    d: "M10.396 9.396a.5.5 0 0 1 .708 0l1.75 1.75a.497.497 0 0 1-.007.714l-1.743 1.743a.5.5 0 0 1-.708-.707l.897-.896H11a2 2 0 0 0-2 2v1.5a.5.5 0 0 1-1 0V14a3 3 0 0 1 3-3h.293l-.897-.896a.5.5 0 0 1 0-.708"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i582d0e-a",
    x1: 10.222,
    x2: 13.511,
    y1: 3,
    y2: 29.311,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#EBEBEB"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i582d0e-c",
    x1: 11.396,
    x2: 14.897,
    y1: 3,
    y2: 29.256,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#BBB"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#888"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i582d0e-d",
    x1: 8,
    x2: 24,
    y1: 8,
    y2: 24,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i582d0e-e",
    x1: 8,
    x2: 24,
    y1: 8,
    y2: 24,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i582d0e-f",
    x1: 8,
    x2: 24,
    y1: 8,
    y2: 24,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i582d0e-b",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(13.7222 20.58336 -17.81255 11.875 11.306 9.771)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.177,
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#B8B8B8"
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopyJob32Item);

export { ForwardRef as default };
