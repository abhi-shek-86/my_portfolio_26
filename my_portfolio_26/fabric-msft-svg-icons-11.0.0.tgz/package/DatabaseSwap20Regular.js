import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseSwap20Regular = function SvgDatabaseSwap20Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M12.283 3.106c-.173.268-.27.577-.283.895v4a1.81 1.81 0 0 0 .968 1.456 4.07 4.07 0 0 0 4.064 0A1.81 1.81 0 0 0 18 8V4a1.78 1.78 0 0 0-.981-1.52A4.1 4.1 0 0 0 15 2a4.1 4.1 0 0 0-2.019.48 1.8 1.8 0 0 0-.698.625Zm.717.895c0-.213.126-.448.483-.655.468-.243.99-.361 1.517-.345a3.1 3.1 0 0 1 1.517.345c.357.207.483.442.483.655s-.126.448-.483.655c-.468.242-.99.36-1.517.345a3.1 3.1 0 0 1-1.517-.345C13.126 4.449 13 4.214 13 4Zm2 2a4.1 4.1 0 0 0 2-.47l.008 2.47c0 .123-.111.365-.5.607a3.07 3.07 0 0 1-3.008 0c-.393-.242-.5-.484-.5-.607V5.53A4.1 4.1 0 0 0 15 6ZM2.283 11.107c-.173.267-.27.576-.283.894v4a1.81 1.81 0 0 0 .968 1.456A3.9 3.9 0 0 0 5 18a3.9 3.9 0 0 0 2.032-.544A1.81 1.81 0 0 0 8 16v-4a1.78 1.78 0 0 0-.981-1.52A4.1 4.1 0 0 0 5 10a4.1 4.1 0 0 0-2.019.48 1.8 1.8 0 0 0-.698.626ZM3 12c0-.213.126-.448.483-.655.468-.243.99-.361 1.517-.345a3.1 3.1 0 0 1 1.517.345c.357.207.483.442.483.655s-.126.448-.483.655c-.468.242-.99.36-1.517.345a3.1 3.1 0 0 1-1.517-.345C3.126 12.449 3 12.214 3 12m2 2a4.1 4.1 0 0 0 2-.47V16c0 .123-.111.365-.5.607-.455.264-.974.4-1.5.393a2.9 2.9 0 0 1-1.5-.393c-.393-.242-.5-.484-.5-.607v-2.47A4.1 4.1 0 0 0 5 14m10.943-1.723a.5.5 0 0 0-.5.5 1.36 1.36 0 0 1-1.357 1.358H11.65l1.013-1.013a.5.5 0 0 0-.707-.707L10.09 14.28a.5.5 0 0 0 0 .707l1.866 1.867a.5.5 0 1 0 .707-.708l-1.013-1.012h2.436a2.36 2.36 0 0 0 2.357-2.358.5.5 0 0 0-.5-.5ZM4.354 7.578a.5.5 0 0 1-.854-.353 2.36 2.36 0 0 1 2.357-2.358h2.436L7.28 3.855a.5.5 0 0 1 .707-.708l1.867 1.867a.5.5 0 0 1 0 .707L7.987 7.587a.5.5 0 1 1-.707-.707l1.013-1.013H5.857A1.36 1.36 0 0 0 4.5 7.225a.5.5 0 0 1-.146.353"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseSwap20Regular);

export { ForwardRef as default };
