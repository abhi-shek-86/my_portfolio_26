import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot28Filled = function SvgCopilot28Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 28,
    height: 28,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M23.002 8a4 4 0 0 1 3.878 4.98l-2.336 9.245A5 5 0 0 1 19.696 26h-6.191c-2.607 0-4.517-2.453-3.878-4.98L9.885 20h2.09a4 4 0 0 0 3.879-3.02L18.122 8zm-8.5-6a4 4 0 0 1 3.878 4.98L18.122 8h-2.087a4 4 0 0 0-3.878 3.02L9.885 20h-4.88c-2.607 0-4.517-2.453-3.878-4.98l2.339-9.247A5 5 0 0 1 8.313 2z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot28Filled);

export { ForwardRef as default };
