import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataEngineering16Regular = function SvgDataEngineering16Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M13.36 5.43s-1.601 2.38-4.58 4.14c-.45-.35-.82-.76-1.18-1.33l-.84-1.32c.464-.402.84-.707 1.48-1.21a12 12 0 0 0 3.21-3.89c.2-.39-.08-.82-.51-.82H5.49c-.3 0-.58.12-.8.34L1.34 4.79c-.17.18-.34.487-.34.81v4.87c0 .31.12.6.32.83 0 0 0 .02.01.02l3.12 3.34c.21.23.51.36.81.36h4.66c.29 0 .56-.13.77-.33L12 13.4l2.19-2.2.43-.43c.24-.23.38-.55.39-.88V6.08c0-.93-1.08-1.52-1.67-.65zm-3.65 4.75.46.26c1.03.51 2.2.42 3 .15.86-.29.86-.74.86-.74V6.18a.2.2 0 0 1-.04.06c-.1.14-.24.32-.43.55-.37.45-.93 1.06-1.65 1.72a16.6 16.6 0 0 1-2.2 1.67M6 7.57c.056-.05-.06.054 0 0M1.98 5.63s.02-.09.05-.12l3.35-3.44s.07-.05.11-.05h4.71c-.52.84-1.34 1.92-2.55 2.87-1.86 1.46-2.98 2.5-3.68 3.4-.74.95-.97 1.73-1.14 2.56-.03.17-.06.34-.08.51l-.73-.78s-.04-.07-.04-.11zm9.69 6.65-1.65 1.65s-.09.05-.11.05H5.26s-.08-.02-.11-.05L3.9 12.59l-.03-.04c-.19-.47-.19-.97-.09-1.49.23-1.1.53-1.92 2.22-3.49l.77 1.22c.82 1.28 1.77 1.95 2.98 2.55.81.4 1.66.5 2.41.45z",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataEngineering16Regular);

export { ForwardRef as default };
