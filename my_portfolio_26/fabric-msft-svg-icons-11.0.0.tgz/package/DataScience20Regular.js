import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataScience20Regular = function SvgDataScience20Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M9.726 17.967a.9.9 0 0 0 .575-.028l5.718-2.45a.633.633 0 0 0 .225-.996L13.74 11.63l3.14-4.959.003-.006c.16-.255.243-.551.243-.854 0-.655-.39-1.246-.987-1.497l-.025-.01-5.51-1.972a1.86 1.86 0 0 0-1.339-.008l-5.25 1.88a1 1 0 0 0-.566 1.37c.012.03.055.1.043.084l3.193 4.703-2.908 2.93-.023.026a1.633 1.633 0 0 0 .59 2.564l5.383 2.087Zm-2.47-6.764 2.401-2.419a.93.93 0 0 0 .226-.613.95.95 0 0 0-.502-.834L4.35 5.144l5.253-1.881a1 1 0 0 1 .324-.06q.17.001.324.064l5.498 1.968a.62.62 0 0 1 .375.575c0 .12-.033.232-.091.325l-2.982 4.71-3.732 5.894-.312-.122-4.275-1.658a.633.633 0 0 1-.222-.99l2.745-2.766Z",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataScience20Regular);

export { ForwardRef as default };
