import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataEngineering32Regular = function SvgDataEngineering32Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M4.002 21.128a.33.33 0 0 1-.088-.227v-9.657a.33.33 0 0 1 .093-.232l6.697-6.892a.3.3 0 0 1 .22-.094h9.402c-1.03 1.68-2.67 3.845-5.089 5.745-3.723 2.926-5.959 4.997-7.34 6.79-1.471 1.909-1.939 3.459-2.285 5.12q-.104.499-.153 1.011zm4.85 8.146-6.504-7.046c-.391-.42-.39-.683-.39-1.236v-9.748c0-.633.244-1.24.676-1.685L9.33 2.668a2.22 2.22 0 0 1 1.593-.682h10.89c.847 0 1.402.869 1.002 1.647C21.844 5.52 19.85 8.7 16.414 11.4a93 93 0 0 0-2.955 2.41l1.67 2.642c.716 1.122 1.484 1.968 2.373 2.677 5.96-3.516 9.131-8.294 9.131-8.294 1.178-1.734 3.325-.558 3.325 1.295v7.62a2.68 2.68 0 0 1-.788 1.757l-5.23 5.256-.008-.007-2.609 2.57c-.419.409-.972.658-1.546.66h-9.298a2.22 2.22 0 0 1-1.627-.713Zm-1.329-7.16c.458-2.195 1.061-3.844 4.436-6.971l1.542 2.44c1.631 2.558 3.528 3.9 5.96 5.104 1.568.775 3.322 1.002 4.822.9l-4.298 4.252a.34.34 0 0 1-.212.107h-9.298a.3.3 0 0 1-.223-.097h-.001l-2.547-2.735-.01-.023c-.382-.932-.388-1.935-.17-2.977Zm11.84-1.759q.447.247.936.488c2.056 1.018 4.389.825 5.985.294q.385-.128.706-.277l.386-.186c.384-.185.627-.573.627-.999v-7.34l-.084.116c-.196.267-.483.642-.857 1.096a33 33 0 0 1-3.3 3.444 33 33 0 0 1-4.4 3.364Z",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataEngineering32Regular);

export { ForwardRef as default };
