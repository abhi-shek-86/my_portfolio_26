import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCubeConeArrowCurvedRight20Filled = function SvgCubeConeArrowCurvedRight20Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M7.863 2.146a.5.5 0 1 0-.707.708L8.294 3.99H6.5A2.5 2.5 0 0 0 4 6.49a.5.5 0 0 0 1 0 1.5 1.5 0 0 1 1.5-1.5h1.794L7.156 6.128a.5.5 0 1 0 .707.708l1.991-1.991a.5.5 0 0 0 0-.708l-1.99-1.99Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M17.93 9.936a3 3 0 0 0-.18-.469l-3.305-6.69a.45.45 0 0 0-.187-.2.5.5 0 0 0-.25-.064L14 2.516h-.008a.5.5 0 0 0-.25.063.45.45 0 0 0-.187.2L10.25 9.467a3 3 0 0 0-.08.179L7.174 8.147a1.53 1.53 0 0 0-1.344 0l-3 1.5a1.4 1.4 0 0 0-.609.555 1.5 1.5 0 0 0-.22.789v3.765c.004.278.083.55.227.789.14.24.35.434.6.555l3 1.5a1.53 1.53 0 0 0 1.344 0l3-1.5a1.4 1.4 0 0 0 .609-.555c.145-.238.22-.51.22-.789v-2.663q.279.205.594.351.39.184.8.32c.494.15 1.008.227 1.524.227l.04-.002a.4.4 0 0 1 .077 0l.04.002c.516 0 1.029-.076 1.523-.227q.41-.135.8-.32.425-.197.782-.5c.23-.193.428-.423.585-.68.154-.249.235-.535.235-.828q0-.255-.07-.5Zm-9.2 1.883L7 12.686v2.19a.5.5 0 0 1-1 0v-2.19l-1.727-.867a.45.45 0 0 1-.2-.188.6.6 0 0 1-.073-.255.505.505 0 0 1 .727-.446l1.773.881 1.773-.883a.51.51 0 0 1 .58.096c.093.093.146.22.147.352 0 .09-.025.178-.07.255a.45.45 0 0 1-.2.188"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCubeConeArrowCurvedRight20Filled);

export { ForwardRef as default };
