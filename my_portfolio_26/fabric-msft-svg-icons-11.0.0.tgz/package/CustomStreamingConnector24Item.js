import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCustomStreamingConnector24Item = function SvgCustomStreamingConnector24Item(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie73c2d-i1eaa94-paint0_linear_62220_714)",
    d: "M2 5a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v11.094C22 17.75 20.657 22 19 22H5a3 3 0 0 1-3-3z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie73c2d-i1eaa94-paint1_radial_62220_714)",
    fillOpacity: 0.2,
    d: "M2 5a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v11.094C22 17.75 20.657 22 19 22H5a3 3 0 0 1-3-3z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie73c2d-i1eaa94-paint2_linear_62220_714)",
    fillRule: "evenodd",
    d: "M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2M5 2a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h14c1.657 0 3-4 3-5.656V5a3 3 0 0 0-3-3z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie73c2d-i1eaa94-paint3_linear_62220_714)",
    d: "M8.658 11.1a1.227 1.227 0 0 1 1.735 0l2.507 2.508a1.227 1.227 0 0 1 0 1.735l-.193.193a3 3 0 0 1-3.862.32l-1.982 1.997a.5.5 0 0 1-.71-.705l1.985-2a3 3 0 0 1 .326-3.855zm8.498-4.961a.5.5 0 0 1 .69.723L15.82 8.793a3 3 0 0 1-.284 3.914l-.193.193a1.23 1.23 0 0 1-1.736 0L11.1 10.393a1.23 1.23 0 0 1 0-1.736l.193-.193a3 3 0 0 1 3.803-.363z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#F5F5F5",
    fillRule: "evenodd",
    d: "M20.965 12.008A1.5 1.5 0 0 1 22.224 14h.276a1.5 1.5 0 0 1 1.115 2.5c.207.23.344.522.377.847L24 17.5a1.5 1.5 0 0 1-1.5 1.5h-1a5 5 0 0 1-4.743 4.993L16.5 24h-1a1.5 1.5 0 0 1-1.5-1.5l.008-.153a1.5 1.5 0 0 1 .098-.4 1.5 1.5 0 0 1-1.098-1.294L13 20.5l.008-.153c.033-.325.17-.617.377-.847a1.5 1.5 0 0 1-.377-.847L13 18.5l.008-.153A1.5 1.5 0 0 1 14.5 17h.533a5.615 5.615 0 0 1 5.581-5h.197z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie73c2d-i1eaa94-paint4_linear_62220_714)",
    d: "M22.5 17a.5.5 0 0 1 0 1h-1.306a.695.695 0 0 0-.694.694l-.002.012.002.013V19a4 4 0 0 1-4 4h-1a.5.5 0 0 1 0-1h1a3 3 0 0 0 3-3v-.281l.001-.013-.001-.012c0-.935.759-1.694 1.694-1.694z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie73c2d-i1eaa94-paint5_linear_62220_714)",
    d: "M22.5 15a.5.5 0 0 1 0 1h-1.602C19.85 16 19 16.85 19 17.898V18a3 3 0 0 1-3 3h-1.5a.5.5 0 0 1 0-1H16a2 2 0 0 0 2-2v-.148l.001-.018A2.9 2.9 0 0 1 20.898 15z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie73c2d-i1eaa94-paint6_linear_62220_714)",
    d: "M20.81 13a.5.5 0 0 1 0 1h-.196A3.614 3.614 0 0 0 17 17.614 1.406 1.406 0 0 1 15.594 19H14.5a.5.5 0 0 1 0-1h1.094a.406.406 0 0 0 .406-.406v-.008A4.615 4.615 0 0 1 20.614 13z"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie73c2d-i1eaa94-paint0_linear_62220_714",
    x1: 7.556,
    x2: 10.085,
    y1: 2,
    y2: 22.239,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#EBEBEB"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "ie73c2d-i1eaa94-paint1_radial_62220_714",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "rotate(56.31 -2.54 11.442)scale(19.0293 16.4677)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.177,
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#B8B8B8"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie73c2d-i1eaa94-paint2_linear_62220_714",
    x1: 8.458,
    x2: 11.151,
    y1: 2,
    y2: 22.197,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#BBB"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#888"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie73c2d-i1eaa94-paint3_linear_62220_714",
    x1: 6.008,
    x2: 18.008,
    y1: 6,
    y2: 17.992,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie73c2d-i1eaa94-paint4_linear_62220_714",
    x1: 14,
    x2: 23.945,
    y1: 13,
    y2: 21.95,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie73c2d-i1eaa94-paint5_linear_62220_714",
    x1: 14,
    x2: 23.945,
    y1: 13,
    y2: 21.95,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie73c2d-i1eaa94-paint6_linear_62220_714",
    x1: 14,
    x2: 23.945,
    y1: 13,
    y2: 21.95,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCustomStreamingConnector24Item);

export { ForwardRef as default };
