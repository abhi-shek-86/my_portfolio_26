import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataScience20Color = function SvgDataScience20Color(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie8bec8-a)",
    d: "M10.356 17.93a1 1 0 0 1-.908-.1c-.46-.304-.723-1-.415-1.46l3.89-5.785 3.574 4.01a.665.665 0 0 1-.056.94.6.6 0 0 1-.188.12z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie8bec8-b)",
    d: "M7.221 11.004 3.435 5.307a.64.64 0 0 1-.1-.348c0-.368.3-.668.667-.668.092 0 .216-.016.296.016l6.158 2.895-.352.7z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie8bec8-c)",
    d: "M9.644 17.933a1.003 1.003 0 0 1-.476-1.487l7.397-11.135a.665.665 0 0 0-.312-.964l-5.897-2.275A1 1 0 0 0 10 2.004q-.187.002-.356.064L3.746 4.343a.68.68 0 0 1 .516 0l4.654 2.243c.34.176.58.504.58.908a.98.98 0 0 1-.248.655l-5.742 6.446a.665.665 0 0 0 .056.94q.085.076.188.12l5.898 2.274"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#ie8bec8-d)",
    d: "M4.274 4.343 8.93 6.586c.275.14.48.384.551.684l7.185-2.411a.66.66 0 0 0-.395-.516l-5.898-2.275A1 1 0 0 0 10.016 2c-.124 0-.244.024-.356.064L3.763 4.339a.68.68 0 0 1 .516 0z"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie8bec8-a",
    x1: 10.128,
    x2: 14.586,
    y1: 13.328,
    y2: 17.07,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#292941"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.22,
    stopColor: "#114A85"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.44,
    stopColor: "#0A5BA0"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.65,
    stopColor: "#0669B6"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie8bec8-b",
    x1: 4.918,
    x2: 9.196,
    y1: 3.507,
    y2: 9.621,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.22,
    stopColor: "#114A85"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.85,
    stopColor: "#0669B6"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie8bec8-c",
    x1: 10,
    x2: 10,
    y1: 17.933,
    y2: 2.004,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.1,
    stopColor: "#288CD9"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.75,
    stopColor: "#3CC5EE"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "ie8bec8-d",
    x1: 9.54,
    x2: 10.832,
    y1: 2.096,
    y2: 6.906,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#A1ECFF",
    stopOpacity: 0.9
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.92,
    stopColor: "#A1ECFF",
    stopOpacity: 0
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataScience20Color);

export { ForwardRef as default };
