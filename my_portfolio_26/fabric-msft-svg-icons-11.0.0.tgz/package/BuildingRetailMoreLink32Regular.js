import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgBuildingRetailMoreLink32Regular = function SvgBuildingRetailMoreLink32Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M6.771 4.698A2 2 0 0 1 8.29 4h16.08a2 2 0 0 1 1.518.698l4.286 5c1.112 1.298.19 3.302-1.519 3.302h-.325v4.266A5.7 5.7 0 0 0 26.603 17h-.273v-4h-20v11.5a1.5 1.5 0 0 0 1.5 1.5h7.502a5.76 5.76 0 0 0 2.386 2H7.83a3.5 3.5 0 0 1-3.5-3.5V13h-.326c-1.709 0-2.63-2.004-1.519-3.302zM24.37 6H8.29l-4.286 5h24.651z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M17.43 17.64a5.76 5.76 0 0 0-2.458 2.463 1.75 1.75 0 0 1 2.459-2.464ZM12.83 19a1.75 1.75 0 1 1-3.5 0 1.75 1.75 0 0 1 3.5 0m3 3.75a4.25 4.25 0 0 1 4.25-4.25h1a.75.75 0 0 1 0 1.5h-1a2.75 2.75 0 1 0 0 5.5h1a.75.75 0 0 1 0 1.5h-1a4.25 4.25 0 0 1-4.25-4.25m15 0a4.25 4.25 0 0 0-4.25-4.25h-1.5a.75.75 0 0 0 0 1.5h1.5a2.75 2.75 0 1 1 0 5.5h-1.5a.75.75 0 0 0 0 1.5h1.5a4.25 4.25 0 0 0 4.25-4.25"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M19.83 22.75a.75.75 0 0 1 .75-.75h5.5a.75.75 0 0 1 0 1.5h-5.5a.75.75 0 0 1-.75-.75"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgBuildingRetailMoreLink32Regular);

export { ForwardRef as default };
