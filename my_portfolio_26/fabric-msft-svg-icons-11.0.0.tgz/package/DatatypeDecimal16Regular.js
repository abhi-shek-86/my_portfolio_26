import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatatypeDecimal16Regular = function SvgDatatypeDecimal16Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M10.763 5.06a1.1 1.1 0 0 0-.43-.057 1 1 0 0 1-.065 0 1.215 1.215 0 0 0-1.184.709.5.5 0 0 1-.91-.415A2.215 2.215 0 0 1 10.3 4.004a2.11 2.11 0 0 1 2.184 1.734.5.5 0 0 1 .029.17v.075c.004.25.01.692-.215 1.156-.257.528-.77 1.02-1.7 1.442-.992.448-1.359.94-1.499 1.255l-.03.071h2.944a.5.5 0 0 1 0 1h-3.5a.5.5 0 0 1-.489-.395v-.003l-.001-.004-.002-.01a1 1 0 0 1-.014-.1 2 2 0 0 1-.003-.234c.01-.191.054-.446.182-.732.26-.583.833-1.232 2-1.76.79-.357 1.088-.712 1.212-.967.112-.23.116-.435.115-.674a1.105 1.105 0 0 0-.75-.969Zm-6.027-1A.5.5 0 0 1 5 4.501v6a.5.5 0 0 1-1 0V5.435l-.723.482a.5.5 0 1 1-.554-.832l1.5-1a.5.5 0 0 1 .513-.025M7 10.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatatypeDecimal16Regular);

export { ForwardRef as default };
