import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatatypeByte20Filled = function SvgDatatypeByte20Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M6.083 7.108a.75.75 0 0 1 1.029.257l.857 1.428.857-1.428a.75.75 0 0 1 1.286.772l-1.393 2.322v2.292a.75.75 0 0 1-1.5 0V10.46L5.826 8.137a.75.75 0 0 1 .257-1.029m5.23-.107a.75.75 0 0 0 0 1.5h.392v4.25a.75.75 0 0 0 1.5 0v-4.25h.357a.75.75 0 0 0 0-1.5h-2.25Zm3.625.75a.75.75 0 0 1 .75-.75h2a.75.75 0 0 1 0 1.5h-1.25v1h.75a.75.75 0 0 1 0 1.5h-.75v1h1.25a.75.75 0 0 1 0 1.5h-2a.75.75 0 0 1-.75-.75z"
  }), /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M1 12.751v-5a.75.75 0 0 1 .75-.75h1.508c.168 0 .662 0 1.125.26.25.141.49.356.66.668.17.309.25.672.25 1.08 0 .406-.09.747-.241 1.025q.157.147.283.35c.191.314.283.688.283 1.108 0 .844-.403 1.401-.923 1.704A2.44 2.44 0 0 1 3.5 13.5H1.87v-.01a.75.75 0 0 1-.871-.74Zm1.5-.75h1c.12 0 .309-.025.441-.102a.3.3 0 0 0 .116-.11.6.6 0 0 0 .06-.296c0-.201-.042-.293-.063-.328a.23.23 0 0 0-.1-.087c-.137-.067-.327-.077-.518-.077H2.5zm.113-2.5h.668a.76.76 0 0 0 .358-.086.25.25 0 0 0 .095-.097.6.6 0 0 0 .06-.308c0-.212-.042-.316-.066-.36a.2.2 0 0 0-.08-.081c-.097-.055-.241-.068-.398-.068H2.5v1z",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatatypeByte20Filled);

export { ForwardRef as default };
