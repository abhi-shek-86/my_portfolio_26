import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseKql24Regular = function SvgDatabaseKql24Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M4.774 4.22C4.315 4.708 4 5.31 4 6v12c0 .691.315 1.294.774 1.78.455.483 1.079.883 1.793 1.203C7.996 21.623 9.917 22 12 22h.13a2.25 2.25 0 0 1 .284-1.505q-.206.006-.414.005c-1.921 0-3.625-.35-4.82-.886-.598-.268-1.036-.568-1.315-.863-.275-.291-.365-.544-.365-.75V8.392c.32.22.68.417 1.067.59C7.996 9.622 9.917 10 12 10s4.004-.377 5.433-1.018c.386-.173.746-.37 1.067-.59v4.072l1.5-.012V6c0-.69-.315-1.293-.774-1.78-.455-.482-1.079-.882-1.793-1.202C16.004 2.378 14.083 2 12 2s-4.004.377-5.433 1.018c-.714.32-1.338.72-1.793 1.203Zm1.091 2.53C5.59 6.46 5.5 6.208 5.5 6c0-.206.09-.459.365-.75.279-.295.717-.595 1.315-.863C8.375 3.85 10.08 3.5 12 3.5s3.625.351 4.82.887c.598.268 1.036.568 1.315.863.275.291.365.544.365.75 0 .207-.09.46-.365.75-.279.296-.717.596-1.315.864-1.195.536-2.899.886-4.82.886s-3.625-.35-4.82-.886c-.598-.268-1.036-.568-1.315-.863Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M15.227 13.99a.5.5 0 0 0-.35.854l3.53 3.529v.001l1.086 1.087v-.001l1.656 1.656a.5.5 0 0 0 .854-.35l.049-6.32a.5.5 0 0 0-.504-.505zm-.554 6.27h-.002l-.85.85a.75.75 0 0 0-.166.81h.002a.75.75 0 0 0 1.227.25l2.121-2.12a.75.75 0 0 0-1.06-1.061zm.387-2.155a.75.75 0 0 0-1.061-1.06l-.707.706a.75.75 0 0 0 1.06 1.061zm3.888 2.829a.75.75 0 0 1 0 1.06l-.707.707a.75.75 0 0 1-1.06-1.06l.707-.707a.75.75 0 0 1 1.06 0"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseKql24Regular);

export { ForwardRef as default };
