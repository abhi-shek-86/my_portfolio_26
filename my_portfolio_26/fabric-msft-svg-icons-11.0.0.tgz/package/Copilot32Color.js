import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot32Color = function SvgCopilot32Color(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 32,
    height: 32,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i8312dd-paint0_linear_42584_82292)",
    d: "M16.247 2H9.56a6 6 0 0 0-5.816 4.529L1.153 16.774C.353 19.933 2.742 23 6 23h5.098l2.587-10.226A5 5 0 0 1 18.532 9h2.366l.196-.775C21.892 5.066 19.504 2 16.247 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i8312dd-paint1_radial_42584_82292)",
    d: "M16.247 2H9.56a6 6 0 0 0-5.816 4.529L1.153 16.774C.353 19.933 2.742 23 6 23h5.098l2.587-10.226A5 5 0 0 1 18.532 9h2.366l.196-.775C21.892 5.066 19.504 2 16.247 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i8312dd-paint2_linear_42584_82292)",
    d: "M16.247 2H9.56a6 6 0 0 0-5.816 4.529L1.153 16.774C.353 19.933 2.742 23 6 23h5.098l2.587-10.226A5 5 0 0 1 18.532 9h2.366l.196-.775C21.892 5.066 19.504 2 16.247 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i8312dd-paint3_radial_42584_82292)",
    d: "m28.256 25.47 2.588-10.245C31.642 12.066 29.254 9 25.996 9h-5.097l-2.583 10.225A5 5 0 0 1 13.468 23h-2.37l-.196.774C10.103 26.933 12.491 30 15.75 30h6.688a6 6 0 0 0 5.818-4.53"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i8312dd-paint4_linear_42584_82292)",
    d: "m28.256 25.47 2.588-10.245C31.642 12.066 29.254 9 25.996 9h-5.097l-2.583 10.225A5 5 0 0 1 13.468 23h-2.37l-.196.774C10.103 26.933 12.491 30 15.75 30h6.688a6 6 0 0 0 5.818-4.53"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i8312dd-paint0_linear_42584_82292",
    x1: 8.038,
    x2: 8.219,
    y1: 4.545,
    y2: 23.918,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.178,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD000"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i8312dd-paint1_radial_42584_82292",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(-13.8364 24.204 -55.1403 -19.2416 17.343 2)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.252,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD400"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i8312dd-paint2_linear_42584_82292",
    x1: 9.936,
    x2: 9.833,
    y1: 2,
    y2: 23,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#3DCBFF"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.247,
    stopColor: "#0588F7",
    stopOpacity: 0
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i8312dd-paint3_radial_42584_82292",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(11.2643 -25.9538 66.0452 22.3899 13.024 31.67)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.074,
    stopColor: "#FFB152"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.5,
    stopColor: "#F2598A"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.948,
    stopColor: "#8C48FF"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i8312dd-paint4_linear_42584_82292",
    x1: 23.51,
    x2: 23.535,
    y1: 7.727,
    y2: 13.932,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.11,
    stopColor: "#F8ADFA"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.708,
    stopColor: "#A86EDD",
    stopOpacity: 0
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot32Color);

export { ForwardRef as default };
