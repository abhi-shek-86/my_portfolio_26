import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseMultipleKql20Filled = function SvgDatabaseMultipleKql20Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M7.485 2.868c-1.05.479-2.388 1.421-2.48 2.963C2.672 5.42 1 4.308 1 3c0-1.657 2.686-3 6-3 2.618 0 4.845.838 5.664 2.007Q12.334 1.995 12 2a11.2 11.2 0 0 0-4.484.854L7.5 2.86zM2.31 6.016c.766.383 1.685.666 2.69.828v2.222a2.5 2.5 0 0 0-1 0V8.5a2.5 2.5 0 0 0-3-2.45v-.93c.383.363.84.662 1.31.896m5.958 9.268-1.329 1.329c.881.69 2.31 1.187 3.982 1.34l.777-.778c-.199-.1-.299-.2-.398-.3-.6-.6-.6-1.5 0-2.1l.7-.7c.05-.05.125-.1.2-.15l.12-.082.02-.126-.04-.041c-.2-.2-.4-.5-.4-.8-.1-.3 0-.6.1-.9s.3-.5.6-.7.5-.3.8-.3H18V8.12a5.5 5.5 0 0 1-1.31.895C15.438 9.641 13.778 10 12 10s-3.438-.359-4.69-.985A5.5 5.5 0 0 1 6 8.121v1.394q.142.107.268.233l2 2a2.5 2.5 0 0 1 0 3.536"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 9c3.314 0 6-1.343 6-3 0-1.656-2.686-3-6-3S6 4.344 6 6c0 1.657 2.686 3 6 3m-7.146 6.87a.5.5 0 0 1-.708-.708L5.3 14.016a4.5 4.5 0 0 1-4.3-4.5V8.5a.5.5 0 1 1 1 0v1.016a3.5 3.5 0 0 0 3.286 3.494l-1.14-1.14a.5.5 0 0 1 .708-.708l2 2a.5.5 0 0 1 0 .708zm8.63-3.866h5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-.853.354l-5-5a.5.5 0 0 1 .353-.854m.056 2.654a.5.5 0 0 1 0 .707l-.706.707a.5.5 0 1 1-.708-.707l.708-.707a.5.5 0 0 1 .707 0Zm2.83 2.828a.5.5 0 0 1 0 .707l-.708.707a.5.5 0 1 1-.707-.707l.707-.707a.5.5 0 0 1 .707 0Zm-1.415-1.414a.5.5 0 0 1 0 .707L12.834 18.9a.5.5 0 1 1-.708-.707l2.122-2.121a.5.5 0 0 1 .707 0"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseMultipleKql20Filled);

export { ForwardRef as default };
