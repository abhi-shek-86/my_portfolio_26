import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCubeConeArrowCurvedRight20Regular = function SvgCubeConeArrowCurvedRight20Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M7.863 2.146a.5.5 0 1 0-.707.708L8.294 3.99H6.5A2.5 2.5 0 0 0 4 6.49a.5.5 0 0 0 1 0 1.5 1.5 0 0 1 1.5-1.5h1.794L7.156 6.128a.5.5 0 1 0 .707.708l1.991-1.991a.5.5 0 0 0 0-.708l-1.99-1.99ZM6 12.686l-1.727-.867a.45.45 0 0 1-.2-.188.6.6 0 0 1-.073-.255.505.505 0 0 1 .727-.446l1.773.881 1.773-.883a.51.51 0 0 1 .58.096.505.505 0 0 1 .077.609.45.45 0 0 1-.2.188L7 12.686v2.19a.5.5 0 0 1-1 0z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M2 14.756v-3.765a1.5 1.5 0 0 1 .219-.789 1.4 1.4 0 0 1 .609-.555l3-1.5a1.53 1.53 0 0 1 1.344 0l3 1.5a1.4 1.4 0 0 1 .36.25l3.023-6.118a.45.45 0 0 1 .187-.2.5.5 0 0 1 .25-.063H14l.008-.003c.087 0 .173.021.25.063a.45.45 0 0 1 .187.2l3.305 6.69q.11.228.18.47.07.244.07.5c0 .292-.081.58-.235.828a2.8 2.8 0 0 1-.585.68q-.357.303-.782.5-.39.184-.8.32a5.2 5.2 0 0 1-1.563.224l-.039-.002-.039.002a5.2 5.2 0 0 1-1.563-.225 7 7 0 0 1-.8-.32 3.4 3.4 0 0 1-.594-.35v1.663a1.5 1.5 0 0 1-.219.789 1.4 1.4 0 0 1-.609.555l-3 1.5a1.53 1.53 0 0 1-1.344 0l-3-1.5a1.4 1.4 0 0 1-.6-.555A1.57 1.57 0 0 1 2 14.756m8-3.312v-.453a.5.5 0 0 0-.07-.258.45.45 0 0 0-.2-.188l-3-1.5a.5.5 0 0 0-.454 0l-3 1.5a.46.46 0 0 0-.195.188.6.6 0 0 0-.081.258v3.765c0 .09.024.18.07.258a.45.45 0 0 0 .2.188l3 1.5q.109.05.23.054a.6.6 0 0 0 .227-.054l3-1.5a.46.46 0 0 0 .195-.188.6.6 0 0 0 .078-.258zm6.336.89q.264-.178.47-.421a.8.8 0 0 0 .194-.524.7.7 0 0 0-.048-.242 2 2 0 0 0-.1-.234L14 5.123l-2.853 5.79a1.5 1.5 0 0 0-.1.234.7.7 0 0 0-.047.242.8.8 0 0 0 .2.524q.203.241.464.42.272.188.578.314.26.11.531.187c.38.104.771.157 1.165.157h.124c.394 0 .786-.053 1.165-.157a5 5 0 0 0 .531-.187q.306-.126.578-.313"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCubeConeArrowCurvedRight20Regular);

export { ForwardRef as default };
