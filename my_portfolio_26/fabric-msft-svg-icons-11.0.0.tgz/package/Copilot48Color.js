import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot48Color = function SvgCopilot48Color(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 48,
    height: 48,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i099812-paint0_linear_42584_82282)",
    d: "M24.006 5h-8.647a9 9 0 0 0-8.725 6.793L3.22 25.283C2.102 29.706 5.445 34 10.007 34h7.29l3.723-14.717A7 7 0 0 1 27.806 14h2.905l.072-.285C31.9 9.292 28.567 5 24.006 5"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i099812-paint1_radial_42584_82282)",
    d: "M24.006 5h-8.647a9 9 0 0 0-8.725 6.793L3.22 25.283C2.102 29.706 5.445 34 10.007 34h7.29l3.723-14.717A7 7 0 0 1 27.806 14h2.905l.072-.285C31.9 9.292 28.567 5 24.006 5"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i099812-paint2_linear_42584_82282)",
    d: "M24.006 5h-8.647a9 9 0 0 0-8.725 6.793L3.22 25.283C2.102 29.706 5.445 34 10.007 34h7.29l3.723-14.717A7 7 0 0 1 27.806 14h2.905l.072-.285C31.9 9.292 28.567 5 24.006 5"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i099812-paint3_radial_42584_82282)",
    d: "m41.379 36.204 3.408-13.49C45.904 18.293 42.56 14 38 14h-7.29l-3.717 14.715A7 7 0 0 1 20.206 34h-2.909l-.072.283C16.107 38.706 19.44 43 24.002 43h8.651a9 9 0 0 0 8.726-6.796"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i099812-paint4_linear_42584_82282)",
    d: "m41.379 36.204 3.408-13.49C45.904 18.293 42.56 14 38 14h-7.29l-3.717 14.715A7 7 0 0 1 20.206 34h-2.909l-.072.283C16.107 38.706 19.44 43 24.002 43h8.651a9 9 0 0 0 8.726-6.796"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i099812-paint0_linear_42584_82282",
    x1: 12.733,
    x2: 12.982,
    y1: 8.514,
    y2: 35.268,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.178,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD000"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i099812-paint1_radial_42584_82282",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(-19.1634 33.4246 -76.369 -26.5718 25.62 5)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.252,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD400"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i099812-paint2_linear_42584_82282",
    x1: 15.363,
    x2: 15.22,
    y1: 5,
    y2: 34.001,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#3DCBFF"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.247,
    stopColor: "#0588F7",
    stopOpacity: 0
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i099812-paint3_radial_42584_82282",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(15.6011 -35.8409 91.4723 30.9194 20.131 45.307)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.074,
    stopColor: "#FFB152"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.5,
    stopColor: "#F2598A"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.948,
    stopColor: "#8C48FF"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i099812-paint4_linear_42584_82282",
    x1: 34.653,
    x2: 34.688,
    y1: 12.242,
    y2: 20.811,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.11,
    stopColor: "#F8ADFA"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.708,
    stopColor: "#A86EDD",
    stopOpacity: 0
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot48Color);

export { ForwardRef as default };
