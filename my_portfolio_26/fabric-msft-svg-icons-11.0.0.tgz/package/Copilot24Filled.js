import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot24Filled = function SvgCopilot24Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillOpacity: 0.859,
    d: "M19.5 7a3.5 3.5 0 0 1 3.395 4.357l-1.832 7.246A4.5 4.5 0 0 1 16.701 22h-4.944a3.5 3.5 0 0 1-3.394-4.358L8.526 17h1.699a3.5 3.5 0 0 0 3.393-2.643L15.476 7zm-7.254-5a3.5 3.5 0 0 1 3.394 4.357L15.476 7H13.78a3.5 3.5 0 0 0-3.392 2.642L8.526 17H4.502a3.5 3.5 0 0 1-3.394-4.358l1.833-7.246A4.5 4.5 0 0 1 7.304 2z"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot24Filled);

export { ForwardRef as default };
