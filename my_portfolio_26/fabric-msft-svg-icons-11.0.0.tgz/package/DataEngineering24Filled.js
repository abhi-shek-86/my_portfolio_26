import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataEngineering24Filled = function SvgDataEngineering24Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M19.65 8.304s-1.92 2.883-5.55 5.297c.78 1.117 1.56 1.985 2.52 2.454 1.01.498 2.04.728 2.87.748.82.02 1.22-.18 1.34-.27l.63-.618c.34-.33.54-.778.56-1.257V9.231c0-1.316-1.54-2.154-2.38-.927zm-1 9.955s-.91-.21-1.09-.25c-.21-.06-.43-.13-.65-.209-.05-.02-.1-.03-.15-.05-.27-.1-.53-.22-.8-.349-.29-.15-.57-.32-.83-.509-.05-.04-.11-.07-.16-.11a8 8 0 0 1-.71-.618l-.13-.13a10 10 0 0 1-.6-.678c-.02-.02-.04-.05-.06-.07-.21-.259-.4-.528-.59-.798-.21-.299-.41-.598-.61-.907l-.18-.27c-.17-.25-.34-.498-.5-.748l-.62-.918c-1.38.998-2.68 1.886-3.28 2.295-.32.22-.59.399-.81.548-.43.31-.68.52-.9.778-.22.26-.46.629-.8 1.267-.4.778-.34 1.576-.07 2.334.41.978.99 1.676 1.15 1.876l.06.07.63.678.12.12c.29.249.66.389 1.04.389h6.65c.41 0 .81-.18 1.11-.47l1.87-1.835 1.37-1.376c-.14-.01-.31-.04-.46-.06M6.84 12.653c-.09.06-.17.12-.26.18.12-.08.23-.15.35-.24.49-.329 1.45-.987 2.52-1.745-.03.02-.05.03-.08.05.04-.03.07-.05.11-.07.93-.668 1.96-1.417 2.86-2.115 2.46-1.925 3.88-4.19 4.58-5.536a.79.79 0 0 0-.22-1.007.8.8 0 0 0-.5-.17H8.41c-.43 0-.84.17-1.14.489L2.48 7.397c-.31.319-.48.748-.48 1.197v6.882c0 .44.16.858.46 1.177l.95 1.018c0-.08 0-.16.01-.23.03-.538.17-1.097.46-1.655.9-1.726 1.42-2.095 2.96-3.133"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataEngineering24Filled);

export { ForwardRef as default };
