import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot24Color = function SvgCopilot24Color(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#iec7946-paint0_linear_42584_82284)",
    d: "M12.246 2H7.304A4.5 4.5 0 0 0 2.94 5.396L1.11 12.642A3.5 3.5 0 0 0 4.502 17h4.024l1.861-7.358A3.5 3.5 0 0 1 13.78 7h1.697l.162-.643A3.5 3.5 0 0 0 12.246 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#iec7946-paint1_radial_42584_82284)",
    d: "M12.246 2H7.304A4.5 4.5 0 0 0 2.94 5.396L1.11 12.642A3.5 3.5 0 0 0 4.502 17h4.024l1.861-7.358A3.5 3.5 0 0 1 13.78 7h1.697l.162-.643A3.5 3.5 0 0 0 12.246 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#iec7946-paint2_linear_42584_82284)",
    d: "M12.246 2H7.304A4.5 4.5 0 0 0 2.94 5.396L1.11 12.642A3.5 3.5 0 0 0 4.502 17h4.024l1.861-7.358A3.5 3.5 0 0 1 13.78 7h1.697l.162-.643A3.5 3.5 0 0 0 12.246 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#iec7946-paint3_radial_42584_82284)",
    d: "m21.064 18.602 1.83-7.245A3.5 3.5 0 0 0 19.501 7h-4.024l-1.859 7.357A3.5 3.5 0 0 1 10.225 17H8.526l-.162.642A3.5 3.5 0 0 0 11.757 22H16.7a4.5 4.5 0 0 0 4.363-3.398"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#iec7946-paint4_linear_42584_82284)",
    d: "m21.064 18.602 1.83-7.245A3.5 3.5 0 0 0 19.501 7h-4.024l-1.859 7.357A3.5 3.5 0 0 1 10.225 17H8.526l-.162.642A3.5 3.5 0 0 0 11.757 22H16.7a4.5 4.5 0 0 0 4.363-3.398"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "iec7946-paint0_linear_42584_82284",
    x1: 6.138,
    x2: 6.265,
    y1: 3.818,
    y2: 17.656,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.178,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD000"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "iec7946-paint1_radial_42584_82284",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(-10.028 17.2886 -39.9631 -13.744 12.881 2)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.252,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD400"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "iec7946-paint2_linear_42584_82284",
    x1: 7.513,
    x2: 7.441,
    y1: 2,
    y2: 17,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#3DCBFF"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.247,
    stopColor: "#0588F7",
    stopOpacity: 0
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "iec7946-paint3_radial_42584_82284",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(8.19493 -18.5384 48.0486 15.9928 9.92 23.193)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.074,
    stopColor: "#FFB152"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.5,
    stopColor: "#F2598A"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.948,
    stopColor: "#8C48FF"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "iec7946-paint4_linear_42584_82284",
    x1: 17.547,
    x2: 17.565,
    y1: 6.091,
    y2: 10.523,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.11,
    stopColor: "#F8ADFA"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.708,
    stopColor: "#A86EDD",
    stopOpacity: 0
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot24Color);

export { ForwardRef as default };
