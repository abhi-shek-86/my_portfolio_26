import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDataEngineering20Regular = function SvgDataEngineering20Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fillRule: "evenodd",
    d: "M17.57 13.16c.27-.27.43-.63.45-1V7.8c0-1.06-1.23-1.73-1.9-.74 0 0-1.81 2.73-5.22 4.74-.51-.41-.95-.89-1.36-1.53l-.95-1.51c.49-.42 1.04-.87 1.69-1.38 1.97-1.54 3.11-3.36 3.66-4.44a.64.64 0 0 0-.58-.94H7.13c-.34 0-.67.14-.91.39L2.39 6.33c-.19.19-.39.627-.39.92v5.56c0 .35.13.69.37.94l3.57 3.85-3.57-3.84s0 .02.01.02l3.56 3.82c.24.26.58.41.93.41h5.32c.33 0 .65-.14.89-.38zm-5.75-.75c.292.183.339.202.68.37 1.23.61 2.65.46 3.56.12.5-.19.86-.42.95-.62.02-.05.04-.1.04-.15V7.81c0-.06-.02-.1-.04-.14a.1.1 0 0 0-.05-.06l-.123.17-.245.321s-.203.26-.332.419c-.42.51-1.05 1.21-1.87 1.95-.71.63-1.57 1.31-2.57 1.94m-7.7 1.77-1.06-1.13a.33.33 0 0 1-.09-.23V7.29q0-.135.09-.24l3.85-3.93c.06-.06.14-.1.22-.1h5.63c-.58 1-1.57 2.36-3.08 3.55-2.13 1.67-3.4 2.85-4.18 3.86-.82 1.07-1.08 1.93-1.28 2.87-.06.29-.1.59-.1.89zm11.04-.01-2.75 2.72c-.07.07-.16.1-.22.1H6.87c-.09 0-.17-.04-.23-.1L5.6 15.75c-.51-.68-.58-1.44-.41-2.24.27-1.28.62-2.23 2.64-4.08l.89 1.41c.91 1.43 1.98 2.19 3.35 2.87 1.05.52 2.16.59 3.09.46",
    clipRule: "evenodd"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDataEngineering20Regular);

export { ForwardRef as default };
