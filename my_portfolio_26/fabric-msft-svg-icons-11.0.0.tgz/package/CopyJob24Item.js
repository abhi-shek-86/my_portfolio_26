import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopyJob24Item = function SvgCopyJob24Item(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i0e588c-a)",
    d: "M2 5a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v14a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i0e588c-b)",
    fillOpacity: 0.2,
    d: "M2 5a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v14a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i0e588c-c)",
    fillRule: "evenodd",
    d: "M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2M5 2a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V5a3 3 0 0 0-3-3z",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i0e588c-d)",
    fillRule: "evenodd",
    d: "M12.155 6.492C11.56 6.79 11 7.294 11 8v2.005c.344.014.68.057 1 .128v-.708q.077.045.155.083c.626.313 1.456.492 2.345.492s1.719-.18 2.345-.492q.078-.04.155-.083V14c0 .123-.113.369-.602.613-.46.23-1.13.387-1.898.387-.358 0-.696-.034-1-.094v-.67a3 3 0 0 1-.327.203c-.67.366-1.53.561-2.423.561-.894 0-1.752-.195-2.423-.561A3 3 0 0 1 8 14.235v2.312h.001C8.047 17.354 9.26 18 10.75 18s2.703-.646 2.749-1.453h.001v-.625q.48.077 1 .078c.89 0 1.719-.18 2.345-.492C17.44 15.21 18 14.706 18 14V8c0-.706-.559-1.21-1.155-1.508C16.219 6.18 15.389 6 14.5 6s-1.719.18-2.345.492m.447.895c-.49.244-.602.49-.602.613s.113.369.602.613c.46.23 1.13.387 1.898.387s1.438-.157 1.898-.387c.49-.244.602-.49.602-.613s-.113-.369-.602-.613C15.938 7.157 15.268 7 14.5 7s-1.438.157-1.898.387",
    clipRule: "evenodd"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i0e588c-e)",
    d: "M10.75 11a4.6 4.6 0 0 1 1.25.164c.89.248 1.5.753 1.5 1.336 0 .828-1.231 1.5-2.75 1.5S8 13.328 8 12.5 9.231 11 10.75 11"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i0e588c-f)",
    d: "M7.897 6.895a.5.5 0 0 1 .707 0l1.25 1.252a.5.5 0 0 1 0 .706l-1.25 1.252a.5.5 0 1 1-.708-.707l.37-.37A1.56 1.56 0 0 0 7 10.562v.938a.5.5 0 0 1-1 0v-.938a2.563 2.563 0 0 1 2.306-2.55l-.41-.41a.5.5 0 0 1 0-.707Z"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i0e588c-a",
    x1: 7.556,
    x2: 10.085,
    y1: 2,
    y2: 22.239,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#EBEBEB"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i0e588c-c",
    x1: 8.458,
    x2: 11.151,
    y1: 2,
    y2: 22.197,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#BBB"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#888"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i0e588c-d",
    x1: 6,
    x2: 18,
    y1: 6,
    y2: 18,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i0e588c-e",
    x1: 6,
    x2: 18,
    y1: 6,
    y2: 18,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i0e588c-f",
    x1: 6,
    x2: 18,
    y1: 6,
    y2: 18,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#4BA446"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#3F7D35"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i0e588c-b",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "rotate(56.31 -2.54 11.442)scale(19.0293 16.4677)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.177,
    stopColor: "#fff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 1,
    stopColor: "#B8B8B8"
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopyJob24Item);

export { ForwardRef as default };
