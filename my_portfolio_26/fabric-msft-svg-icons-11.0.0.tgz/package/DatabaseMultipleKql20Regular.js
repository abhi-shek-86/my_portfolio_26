import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgDatabaseMultipleKql20Regular = function SvgDatabaseMultipleKql20Regular(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 20,
    height: 20,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M2.9.779C1.875 1.247 1 1.995 1 3.002v3.05a2.5 2.5 0 0 1 1 0v-1.35q.422.309.9.523a10.2 10.2 0 0 0 2.104.618c.02-.356.107-.68.24-.974a9.2 9.2 0 0 1-1.926-.554C2.356 3.877 2 3.375 2 3.002c0-.374.356-.875 1.318-1.313A9.2 9.2 0 0 1 7 1.002a9.2 9.2 0 0 1 3.682.687 4 4 0 0 1 .592.324q.362-.018.726-.011.345-.006.69.009c-.343-.521-.936-.934-1.59-1.232A10.2 10.2 0 0 0 7 .002a10.2 10.2 0 0 0-4.1.777m4.017 15.858c.29.23.627.425.983.588.962.4 1.977.648 3.01.74l.789-.79c-.12-.06-.203-.12-.273-.18a9.2 9.2 0 0 1-3.108-.68 4 4 0 0 1-.688-.391z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M18 10.976V6.002c0-1.007-.875-1.755-1.9-2.223a10.2 10.2 0 0 0-4.1-.777 10.2 10.2 0 0 0-4.1.777C6.875 4.247 6 4.995 6 6.002v3.514q.142.107.268.234l.732.732v-2.78q.422.309.9.523c1.298.54 2.694.804 4.1.777a10.2 10.2 0 0 0 4.1-.775q.479-.215.9-.525v3.274zM8.318 7.315C7.356 6.877 7 6.375 7 6.002c0-.374.356-.875 1.318-1.313A9.2 9.2 0 0 1 12 4.002a9.2 9.2 0 0 1 3.682.687c.962.438 1.318.939 1.318 1.313s-.356.875-1.318 1.313A9.2 9.2 0 0 1 12 8.002a9.2 9.2 0 0 1-3.682-.687m-3.464 8.556a.5.5 0 1 1-.708-.708L5.3 14.017a4.5 4.5 0 0 1-4.3-4.5V8.501a.5.5 0 0 1 1 0v1.016a3.5 3.5 0 0 0 3.286 3.494l-1.14-1.14a.5.5 0 0 1 .708-.708l2 2a.5.5 0 0 1 0 .708zm8.63-3.867h5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-.853.354l-5-5a.5.5 0 0 1 .353-.854m.056 2.654a.5.5 0 0 1 0 .707l-.706.707a.5.5 0 1 1-.708-.707l.708-.707a.5.5 0 0 1 .707 0Zm2.83 2.828a.5.5 0 0 1 0 .707l-.708.707a.5.5 0 1 1-.707-.707l.707-.707a.5.5 0 0 1 .707 0Zm-1.415-1.414a.5.5 0 0 1 0 .707L12.834 18.9a.5.5 0 1 1-.708-.707l2.122-2.121a.5.5 0 0 1 .707 0"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgDatabaseMultipleKql20Regular);

export { ForwardRef as default };
