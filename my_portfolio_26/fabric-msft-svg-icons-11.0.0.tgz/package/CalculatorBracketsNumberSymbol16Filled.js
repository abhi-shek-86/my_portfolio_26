import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCalculatorBracketsNumberSymbol16Filled = function SvgCalculatorBracketsNumberSymbol16Filled(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 16,
    height: 16,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    d: "M1 3.75A2.75 2.75 0 0 1 3.75 1H5.5a.75.75 0 0 1 0 1.5H3.75c-.69 0-1.25.56-1.25 1.25v8.531c0 .69.56 1.25 1.25 1.25H5.5c.196 0 .374.075.507.198q.031.457.17.874a.75.75 0 0 1-.677.428H3.75A2.75 2.75 0 0 1 1 12.281zm13 2.587V3.75A2.75 2.75 0 0 0 11.25 1H9.5a.75.75 0 1 0 0 1.5h1.75c.69 0 1.25.56 1.25 1.25V6c.537 0 1.045.12 1.5.337"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M11 5.5V6h-1v-.5a.5.5 0 0 0-.5-.5h-4a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1.55a3.5 3.5 0 0 0-.713 1H5.5a.5.5 0 0 0 0 1h.535A3.5 3.5 0 0 0 6 9.5v.5h-.5a.5.5 0 0 0 0 1H6v1h-.5A1.5 1.5 0 0 1 4 10.5v-5A1.5 1.5 0 0 1 5.5 4h4A1.5 1.5 0 0 1 11 5.5m.374 6.5h-.97l.222-1.005h.972z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M7 9.5A2.5 2.5 0 0 1 9.5 7h3A2.5 2.5 0 0 1 15 9.5v4a2.5 2.5 0 0 1-2.5 2.5h-3A2.5 2.5 0 0 1 7 13.5zm1.5.995a.5.5 0 0 0 .5.5h.601L9.38 12H8.5a.5.5 0 1 0 0 1h.658l-.142.638a.5.5 0 0 0 .977.216l.189-.854h.969l-.143.637a.5.5 0 0 0 .976.218l.191-.855H13a.5.5 0 0 0 0-1h-.602l.225-1.005h.877a.5.5 0 1 0 0-1h-.654l.141-.633a.5.5 0 0 0-.976-.218l-.19.851h-.974l.14-.634a.5.5 0 1 0-.976-.217l-.188.851H9a.5.5 0 0 0-.5.5"
  }));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCalculatorBracketsNumberSymbol16Filled);

export { ForwardRef as default };
