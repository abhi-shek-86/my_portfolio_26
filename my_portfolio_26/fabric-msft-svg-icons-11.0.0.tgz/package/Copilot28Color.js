import * as React from 'react';
import { forwardRef } from 'react';

var __assign = window && window.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = window && window.__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
var SvgCopilot28Color = function SvgCopilot28Color(_a, ref) {
  var title = _a.title,
    titleId = _a.titleId,
    props = __rest(_a, ["title", "titleId"]);
  return /*#__PURE__*/React.createElement("svg", __assign({
    xmlns: "http://www.w3.org/2000/svg",
    width: 28,
    height: 28,
    fill: "currentColor",
    role: "img",
    focusable: "false",
    ref: ref,
    "aria-labelledby": titleId
  }, props), title ? /*#__PURE__*/React.createElement("title", {
    id: titleId
  }, title) : null, /*#__PURE__*/React.createElement("path", {
    fill: "url(#i98c22c-paint0_linear_42584_82290)",
    d: "M14.502 2H8.313a5 5 0 0 0-4.847 3.774l-2.339 9.245A4 4 0 0 0 5.005 20h4.88l2.272-8.98A4 4 0 0 1 16.035 8h2.087l.258-1.02C19.018 4.453 17.108 2 14.502 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i98c22c-paint1_radial_42584_82290)",
    d: "M14.502 2H8.313a5 5 0 0 0-4.847 3.774l-2.339 9.245A4 4 0 0 0 5.005 20h4.88l2.272-8.98A4 4 0 0 1 16.035 8h2.087l.258-1.02C19.018 4.453 17.108 2 14.502 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i98c22c-paint2_linear_42584_82290)",
    d: "M14.502 2H8.313a5 5 0 0 0-4.847 3.774l-2.339 9.245A4 4 0 0 0 5.005 20h4.88l2.272-8.98A4 4 0 0 1 16.035 8h2.087l.258-1.02C19.018 4.453 17.108 2 14.502 2"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i98c22c-paint3_radial_42584_82290)",
    d: "m24.544 22.225 2.336-9.245C27.518 10.453 25.608 8 23.002 8h-4.88l-2.268 8.98A4 4 0 0 1 11.975 20h-2.09l-.258 1.02A4 4 0 0 0 13.505 26h6.192a5 5 0 0 0 4.847-3.775"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "url(#i98c22c-paint4_linear_42584_82290)",
    d: "m24.544 22.225 2.336-9.245C27.518 10.453 25.608 8 23.002 8h-4.88l-2.268 8.98A4 4 0 0 1 11.975 20h-2.09l-.258 1.02A4 4 0 0 0 13.505 26h6.192a5 5 0 0 0 4.847-3.775"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "i98c22c-paint0_linear_42584_82290",
    x1: 7.111,
    x2: 7.266,
    y1: 4.181,
    y2: 20.787,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.178,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD000"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i98c22c-paint1_radial_42584_82290",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(-11.8478 20.7463 -47.2154 -16.4928 15.079 2)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.252,
    stopColor: "#109DF2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.72,
    stopColor: "#AAD445"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.965,
    stopColor: "#FFD400"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i98c22c-paint2_linear_42584_82290",
    x1: 8.737,
    x2: 8.648,
    y1: 2,
    y2: 20,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    stopColor: "#3DCBFF"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.247,
    stopColor: "#0588F7",
    stopOpacity: 0
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "i98c22c-paint3_radial_42584_82290",
    cx: 0,
    cy: 0,
    r: 1,
    gradientTransform: "matrix(9.6454 -22.2461 56.553 19.1914 11.533 27.432)",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.074,
    stopColor: "#FFB152"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.5,
    stopColor: "#F2598A"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.948,
    stopColor: "#8C48FF"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "i98c22c-paint4_linear_42584_82290",
    x1: 20.512,
    x2: 20.533,
    y1: 6.909,
    y2: 12.227,
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: 0.11,
    stopColor: "#F8ADFA"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: 0.708,
    stopColor: "#A86EDD",
    stopOpacity: 0
  }))));
};
var ForwardRef = /*#__PURE__*/forwardRef(SvgCopilot28Color);

export { ForwardRef as default };
